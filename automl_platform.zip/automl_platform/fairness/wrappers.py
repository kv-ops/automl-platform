"""Fairness-aware model wrappers"""

import numpy as np
import pandas as pd
from sklearn.calibration import CalibratedClassifierCV
from typing import Union, Optional, List, Dict, Any

class ThresholdOptimizedModel:
    """Model with group-specific thresholds for fairness"""
    
    def __init__(self, base_model: Any, protected_attribute: str = None):
        self.base_model = base_model
        self.protected_attribute = protected_attribute
        self.thresholds_ = {}
        self.default_threshold_ = 0.5
        
    def fit(self, X: Union[pd.DataFrame, np.ndarray], y: Union[pd.Series, np.ndarray],
            protected: Optional[Union[pd.Series, np.ndarray]] = None):
        """Fit model and optimize thresholds"""
        
        # Fit base model
        self.base_model.fit(X, y)
        
        # Get predictions
        if hasattr(self.base_model, 'predict_proba'):
            proba = self.base_model.predict_proba(X)[:, 1]
        else:
            proba = self.base_model.decision_function(X)
            proba = 1 / (1 + np.exp(-proba))
        
        # Optimize thresholds per group
        if protected is not None:
            if isinstance(protected, pd.Series):
                protected = protected.values
            
            for group in np.unique(protected):
                mask = protected == group
                group_proba = proba[mask]
                group_y = y[mask] if isinstance(y, np.ndarray) else y.values[mask]
                
                # Find optimal threshold for this group
                best_threshold = 0.5
                best_score = 0
                
                for threshold in np.linspace(0.1, 0.9, 20):
                    preds = (group_proba >= threshold).astype(int)
                    # Use balanced accuracy
                    tp = ((preds == 1) & (group_y == 1)).sum()
                    tn = ((preds == 0) & (group_y == 0)).sum()
                    fp = ((preds == 1) & (group_y == 0)).sum()
                    fn = ((preds == 0) & (group_y == 1)).sum()
                    
                    sensitivity = tp / (tp + fn) if (tp + fn) > 0 else 0
                    specificity = tn / (tn + fp) if (tn + fp) > 0 else 0
                    score = (sensitivity + specificity) / 2
                    
                    if score > best_score:
                        best_score = score
                        best_threshold = threshold
                
                self.thresholds_[group] = best_threshold
        
        return self
    
    def predict(self, X: Union[pd.DataFrame, np.ndarray],
                protected: Optional[Union[pd.Series, np.ndarray]] = None):
        """Predict with group-specific thresholds"""
        
        if hasattr(self.base_model, 'predict_proba'):
            proba = self.base_model.predict_proba(X)[:, 1]
        else:
            proba = self.base_model.decision_function(X)
            proba = 1 / (1 + np.exp(-proba))
        
        if protected is not None and self.thresholds_:
            if isinstance(protected, pd.Series):
                protected = protected.values
            
            predictions = np.zeros(len(proba))
            for group in np.unique(protected):
                mask = protected == group
                threshold = self.thresholds_.get(group, self.default_threshold_)
                predictions[mask] = (proba[mask] >= threshold).astype(int)
        else:
            predictions = (proba >= self.default_threshold_).astype(int)
        
        return predictions
    
    def predict_proba(self, X: Union[pd.DataFrame, np.ndarray]):
        """Get probability predictions"""
        return self.base_model.predict_proba(X) if hasattr(self.base_model, 'predict_proba') else None


class CalibratedGroupModel:
    """Model with group-specific calibration"""
    
    def __init__(self, base_model: Any, protected_attribute: str = None):
        self.base_model = base_model
        self.protected_attribute = protected_attribute
        self.calibrators_ = {}
        self.default_calibrator_ = None
        
    def fit(self, X: Union[pd.DataFrame, np.ndarray], y: Union[pd.Series, np.ndarray],
            protected: Optional[Union[pd.Series, np.ndarray]] = None):
        """Fit model with group-specific calibration"""
        
        # Fit base model
        self.base_model.fit(X, y)
        
        # Calibrate per group
        if protected is not None:
            if isinstance(protected, pd.Series):
                protected = protected.values
            
            for group in np.unique(protected):
                mask = protected == group
                
                # Handle DataFrame/ndarray indexing
                if isinstance(X, pd.DataFrame):
                    X_group = X.iloc[mask]
                else:
                    X_group = X[mask]
                
                y_group = y[mask] if isinstance(y, np.ndarray) else y.iloc[mask]
                
                # Calibrate for this group
                n_samples = len(y_group)
                method = 'isotonic' if n_samples > 1000 else 'sigmoid'
                
                calibrator = CalibratedClassifierCV(
                    self.base_model,
                    method=method,
                    cv='prefit'
                )
                calibrator.fit(X_group, y_group)
                self.calibrators_[group] = calibrator
        
        # Default calibrator
        self.default_calibrator_ = self.base_model
        
        return self
    
    def predict(self, X: Union[pd.DataFrame, np.ndarray],
                protected: Optional[Union[pd.Series, np.ndarray]] = None):
        """Predict with group-specific calibration"""
        
        if protected is not None and self.calibrators_:
            if isinstance(protected, pd.Series):
                protected = protected.values
            
            predictions = np.zeros(len(X), dtype=int)
            
            for group in np.unique(protected):
                mask = protected == group
                calibrator = self.calibrators_.get(group, self.default_calibrator_)
                
                # Handle DataFrame/ndarray indexing with alignment
                if isinstance(X, pd.DataFrame):
                    X_group = X.iloc[mask]
                else:
                    X_group = X[mask]
                
                if len(X_group) > 0:
                    group_preds = calibrator.predict(X_group)
                    
                    # Ensure mask indices align with predictions array
                    mask_indices = np.where(mask)[0]
                    predictions[mask_indices] = group_preds
        else:
            predictions = self.base_model.predict(X)
        
        return predictions
    
    def predict_proba(self, X: Union[pd.DataFrame, np.ndarray],
                      protected: Optional[Union[pd.Series, np.ndarray]] = None):
        """Get calibrated probability predictions"""
        
        if protected is not None and self.calibrators_:
            if isinstance(protected, pd.Series):
                protected = protected.values
            
            n_classes = 2  # Assume binary for now
            probas = np.zeros((len(X), n_classes))
            
            for group in np.unique(protected):
                mask = protected == group
                calibrator = self.calibrators_.get(group, self.default_calibrator_)
                
                if isinstance(X, pd.DataFrame):
                    X_group = X.iloc[mask]
                else:
                    X_group = X[mask]
                
                if len(X_group) > 0:
                    group_probas = calibrator.predict_proba(X_group)
                    
                    # Ensure mask indices align
                    mask_indices = np.where(mask)[0]
                    probas[mask_indices] = group_probas
        else:
            probas = self.base_model.predict_proba(X) if hasattr(self.base_model, 'predict_proba') else None
        
        return probas
