"""Fairness metrics - complete implementation"""

import numpy as np
import pandas as pd
from typing import Dict, Any, Optional, Union, List
from sklearn.metrics import confusion_matrix

def demographic_parity(y_true: Union[np.ndarray, pd.Series],
                       y_pred: Union[np.ndarray, pd.Series],
                       protected: Union[np.ndarray, pd.Series]) -> Dict[str, Any]:
    """
    Calculate demographic parity metrics
    
    Returns difference and ratio of positive prediction rates between groups
    """
    if isinstance(y_true, pd.Series):
        y_true = y_true.values
    if isinstance(y_pred, pd.Series):
        y_pred = y_pred.values
    if isinstance(protected, pd.Series):
        protected = protected.values
    
    groups = np.unique(protected)
    positive_rates = {}
    
    for group in groups:
        mask = protected == group
        group_preds = y_pred[mask]
        positive_rate = np.mean(group_preds)
        positive_rates[str(group)] = positive_rate
    
    rates = list(positive_rates.values())
    
    # Calculate metrics
    parity_diff = max(rates) - min(rates)
    parity_ratio = min(rates) / max(rates) if max(rates) > 0 else 0
    
    return {
        "metric": "demographic_parity",
        "difference": parity_diff,
        "ratio": parity_ratio,
        "by_group": positive_rates,
        "fair": parity_diff < 0.1  # Common threshold
    }

def equal_opportunity(y_true: Union[np.ndarray, pd.Series],
                     y_pred: Union[np.ndarray, pd.Series],
                     protected: Union[np.ndarray, pd.Series]) -> Dict[str, Any]:
    """
    Calculate equal opportunity metrics
    
    Returns TPR difference between groups
    """
    if isinstance(y_true, pd.Series):
        y_true = y_true.values
    if isinstance(y_pred, pd.Series):
        y_pred = y_pred.values
    if isinstance(protected, pd.Series):
        protected = protected.values
    
    groups = np.unique(protected)
    tpr_rates = {}
    
    for group in groups:
        mask = protected == group
        group_true = y_true[mask]
        group_preds = y_pred[mask]
        
        # Calculate TPR (True Positive Rate)
        positive_mask = group_true == 1
        if positive_mask.sum() > 0:
            tpr = np.mean(group_preds[positive_mask])
        else:
            tpr = 0.0
        
        tpr_rates[str(group)] = tpr
    
    rates = list(tpr_rates.values())
    
    # Calculate metrics
    tpr_diff = max(rates) - min(rates)
    tpr_ratio = min(rates) / max(rates) if max(rates) > 0 else 0
    
    return {
        "metric": "equal_opportunity",
        "tpr_difference": tpr_diff,
        "tpr_ratio": tpr_ratio,
        "by_group": tpr_rates,
        "fair": tpr_diff < 0.1
    }

def disparate_impact(y_true: Union[np.ndarray, pd.Series],
                    y_pred: Union[np.ndarray, pd.Series],
                    protected: Union[np.ndarray, pd.Series],
                    reference_group: Optional[Any] = None) -> Dict[str, Any]:
    """
    Calculate disparate impact (80% rule)
    """
    if isinstance(y_true, pd.Series):
        y_true = y_true.values
    if isinstance(y_pred, pd.Series):
        y_pred = y_pred.values
    if isinstance(protected, pd.Series):
        protected = protected.values
    
    groups = np.unique(protected)
    positive_rates = {}
    
    for group in groups:
        mask = protected == group
        group_preds = y_pred[mask]
        positive_rate = np.mean(group_preds)
        positive_rates[str(group)] = positive_rate
    
    # Determine reference group
    if reference_group is None:
        reference_rate = max(positive_rates.values())
    else:
        reference_rate = positive_rates.get(str(reference_group), max(positive_rates.values()))
    
    # Calculate disparate impact ratios
    impact_ratios = {}
    for group, rate in positive_rates.items():
        if reference_rate > 0:
            ratio = rate / reference_rate
        else:
            ratio = 0.0
        impact_ratios[group] = ratio
    
    # Check 80% rule
    min_ratio = min(impact_ratios.values())
    passes_80_rule = min_ratio >= 0.8
    
    return {
        "metric": "disparate_impact",
        "impact_ratios": impact_ratios,
        "min_ratio": min_ratio,
        "passes_80_rule": passes_80_rule,
        "reference_rate": reference_rate,
        "by_group": positive_rates
    }

def fairness_report(y_true: Union[np.ndarray, pd.Series],
                   y_pred: Union[np.ndarray, pd.Series],
                   protected: Union[np.ndarray, pd.Series],
                   metrics: List[str] = None) -> Dict[str, Any]:
    """
    Generate comprehensive fairness report
    """
    if metrics is None:
        metrics = ["demographic_parity", "equal_opportunity", "disparate_impact"]
    
    report = {
        "timestamp": pd.Timestamp.now().isoformat(),
        "n_samples": len(y_true),
        "n_groups": len(np.unique(protected)),
        "metrics": {}
    }
    
    # Calculate each metric
    if "demographic_parity" in metrics:
        report["metrics"]["demographic_parity"] = demographic_parity(y_true, y_pred, protected)
    
    if "equal_opportunity" in metrics:
        report["metrics"]["equal_opportunity"] = equal_opportunity(y_true, y_pred, protected)
    
    if "disparate_impact" in metrics:
        report["metrics"]["disparate_impact"] = disparate_impact(y_true, y_pred, protected)
    
    # Calculate overall fairness score
    fairness_scores = []
    
    if "demographic_parity" in report["metrics"]:
        dp_ratio = report["metrics"]["demographic_parity"]["ratio"]
        fairness_scores.append(dp_ratio)
    
    if "equal_opportunity" in report["metrics"]:
        eo_ratio = report["metrics"]["equal_opportunity"]["tpr_ratio"]
        fairness_scores.append(eo_ratio)
    
    if "disparate_impact" in report["metrics"]:
        di_ratio = report["metrics"]["disparate_impact"]["min_ratio"]
        fairness_scores.append(min(1.0, di_ratio / 0.8))  # Normalize to 0-1
    
    report["fairness_score"] = np.mean(fairness_scores) if fairness_scores else 0.0
    
    # Add recommendations
    report["recommendations"] = []
    
    if report["fairness_score"] < 0.8:
        report["recommendations"].append("Consider using fairness-aware model wrappers")
    
    if "demographic_parity" in report["metrics"]:
        if report["metrics"]["demographic_parity"]["difference"] > 0.1:
            report["recommendations"].append("Large demographic parity gap detected")
    
    if "equal_opportunity" in report["metrics"]:
        if report["metrics"]["equal_opportunity"]["tpr_difference"] > 0.1:
            report["recommendations"].append("Unequal true positive rates across groups")
    
    if "disparate_impact" in report["metrics"]:
        if not report["metrics"]["disparate_impact"]["passes_80_rule"]:
            report["recommendations"].append("Fails 80% rule for disparate impact")
    
    # Recommended thresholds per group for optimization
    groups = np.unique(protected)
    recommended_thresholds = {}
    
    for group in groups:
        mask = protected == group
        group_true = y_true[mask] if isinstance(y_true, np.ndarray) else y_true.values[mask]
        
        # Simple threshold recommendation based on group prevalence
        prevalence = np.mean(group_true)
        if prevalence < 0.3:
            recommended_thresholds[str(group)] = 0.4
        elif prevalence > 0.7:
            recommended_thresholds[str(group)] = 0.6
        else:
            recommended_thresholds[str(group)] = 0.5
    
    report["recommended_thresholds"] = recommended_thresholds
    
    return report
