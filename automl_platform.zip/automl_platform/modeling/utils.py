"""Model utilities"""

import joblib
import pickle
import hashlib
import json
from pathlib import Path
from typing import Any, Union, Optional, Dict
import pandas as pd
import numpy as np
from datetime import datetime

def save_model(model: Any, filepath: Union[str, Path], metadata: Optional[Dict] = None) -> str:
    """Save model with metadata and hash"""
    filepath = Path(filepath)
    filepath.parent.mkdir(parents=True, exist_ok=True)
    
    # Save model
    if filepath.suffix == '.pkl':
        with open(filepath, 'wb') as f:
            pickle.dump(model, f)
    else:
        joblib.dump(model, filepath)
    
    # Calculate hash
    with open(filepath, 'rb') as f:
        model_hash = hashlib.sha256(f.read()).hexdigest()
    
    # Save metadata
    metadata = metadata or {}
    metadata.update({
        'hash': model_hash,
        'saved_at': datetime.now().isoformat(),
        'model_type': type(model).__name__,
        'filepath': str(filepath)
    })
    
    metadata_path = filepath.with_suffix('.meta.json')
    with open(metadata_path, 'w') as f:
        json.dump(metadata, f, indent=2)
    
    return model_hash

def load_model(filepath: Union[str, Path], verify_hash: bool = False) -> Any:
    """Load model with optional hash verification"""
    filepath = Path(filepath)
    
    if not filepath.exists():
        raise FileNotFoundError(f"Model file not found: {filepath}")
    
    # Load metadata if exists
    metadata_path = filepath.with_suffix('.meta.json')
    metadata = {}
    if metadata_path.exists():
        with open(metadata_path, 'r') as f:
            metadata = json.load(f)
    
    # Verify hash if requested
    if verify_hash and 'hash' in metadata:
        with open(filepath, 'rb') as f:
            current_hash = hashlib.sha256(f.read()).hexdigest()
        if current_hash != metadata['hash']:
            raise ValueError(f"Model hash mismatch! Expected {metadata['hash']}, got {current_hash}")
    
    # Load model
    if filepath.suffix == '.pkl':
        with open(filepath, 'rb') as f:
            model = pickle.load(f)
    else:
        model = joblib.load(filepath)
    
    return model

def predict(model: Any, X: Union[pd.DataFrame, np.ndarray]) -> np.ndarray:
    """Universal predict function"""
    if hasattr(model, 'predict'):
        return model.predict(X)
    elif callable(model):
        return model(X)
    else:
        raise ValueError(f"Model {type(model)} does not have predict method")

def predict_proba(model: Any, X: Union[pd.DataFrame, np.ndarray]) -> np.ndarray:
    """Universal predict_proba function"""
    if hasattr(model, 'predict_proba'):
        return model.predict_proba(X)
    elif hasattr(model, 'decision_function'):
        # Convert decision function to probabilities
        scores = model.decision_function(X)
        if len(scores.shape) == 1:
            # Binary classification
            probs = 1 / (1 + np.exp(-scores))
            return np.column_stack([1 - probs, probs])
        else:
            # Multi-class
            exp_scores = np.exp(scores)
            return exp_scores / exp_scores.sum(axis=1, keepdims=True)
    elif hasattr(model, 'predict'):
        # Fallback: return binary probabilities based on predictions
        preds = model.predict(X)
        n_samples = len(preds)
        # Assume binary classification
        probs = np.zeros((n_samples, 2))
        probs[range(n_samples), preds.astype(int)] = 1.0
        return probs
    else:
        raise ValueError(f"Model {type(model)} does not have predict_proba or decision_function method")
