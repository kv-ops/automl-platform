"""Model ensembling strategies"""

import numpy as np
import pandas as pd
from sklearn.ensemble import VotingClassifier, VotingRegressor, StackingClassifier, StackingRegressor
from sklearn.linear_model import LogisticRegression, Ridge
from sklearn.calibration import CalibratedClassifierCV
from typing import List, Any, Optional, Union

def create_voting_ensemble(models: List[Any], task: str = "classification", 
                          voting: str = "soft") -> Any:
    """Create voting ensemble"""
    if task == "classification":
        return VotingClassifier(
            estimators=[(f"model_{i}", model) for i, model in enumerate(models)],
            voting=voting
        )
    else:
        return VotingRegressor(
            estimators=[(f"model_{i}", model) for i, model in enumerate(models)]
        )

def create_stacking_ensemble(models: List[Any], task: str = "classification",
                            meta_model: Optional[Any] = None) -> Any:
    """Create stacking ensemble"""
    if meta_model is None:
        if task == "classification":
            meta_model = LogisticRegression(max_iter=1000)
        else:
            meta_model = Ridge()
    
    if task == "classification":
        return StackingClassifier(
            estimators=[(f"model_{i}", model) for i, model in enumerate(models)],
            final_estimator=meta_model,
            cv=5
        )
    else:
        return StackingRegressor(
            estimators=[(f"model_{i}", model) for i, model in enumerate(models)],
            final_estimator=meta_model,
            cv=5
        )

def create_blending_ensemble(models: List[Any], X_blend: pd.DataFrame, 
                            y_blend: pd.Series, task: str = "classification") -> Any:
    """Create blending ensemble"""
    # Get predictions from base models
    if task == "classification":
        blend_features = np.column_stack([
            model.predict_proba(X_blend)[:, 1] if hasattr(model, 'predict_proba')
            else model.predict(X_blend)
            for model in models
        ])
        
        # Train meta model
        meta_model = LogisticRegression(max_iter=1000)
        meta_model.fit(blend_features, y_blend)
        
    else:
        blend_features = np.column_stack([
            model.predict(X_blend) for model in models
        ])
        
        # Train meta model
        meta_model = Ridge()
        meta_model.fit(blend_features, y_blend)
    
    # Create ensemble wrapper
    class BlendingEnsemble:
        def __init__(self, base_models, meta_model, task):
            self.base_models = base_models
            self.meta_model = meta_model
            self.task = task
        
        def predict(self, X):
            if self.task == "classification":
                features = np.column_stack([
                    model.predict_proba(X)[:, 1] if hasattr(model, 'predict_proba')
                    else model.predict(X)
                    for model in self.base_models
                ])
            else:
                features = np.column_stack([
                    model.predict(X) for model in self.base_models
                ])
            return self.meta_model.predict(features)
        
        def predict_proba(self, X):
            if self.task != "classification":
                raise ValueError("predict_proba only for classification")
            
            features = np.column_stack([
                model.predict_proba(X)[:, 1] if hasattr(model, 'predict_proba')
                else model.predict(X)
                for model in self.base_models
            ])
            return self.meta_model.predict_proba(features)
    
    return BlendingEnsemble(models, meta_model, task)

def calibrate_model(model: Any, X_calib: Union[pd.DataFrame, np.ndarray], 
                   y_calib: Union[pd.Series, np.ndarray]) -> Any:
    """Calibrate model probabilities"""
    n_samples = len(y_calib)
    
    # Choose calibration method based on sample size
    if n_samples > 1000:
        method = 'isotonic'
    else:
        method = 'sigmoid'
    
    calibrated = CalibratedClassifierCV(
        model,
        method=method,
        cv='prefit'  # Model already trained
    )
    
    calibrated.fit(X_calib, y_calib)
    return calibrated
