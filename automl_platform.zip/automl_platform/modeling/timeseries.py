"""Time series modeling"""

import numpy as np
import pandas as pd
from typing import Optional, Dict, Any, Tuple

class TimeSeriesForecaster:
    """Time series forecasting wrapper"""
    
    def __init__(self, method: str = "auto", seasonality: Optional[int] = None):
        self.method = method
        self.seasonality = seasonality
        self.model_ = None
        
    def fit(self, y: pd.Series, exog: Optional[pd.DataFrame] = None):
        """Fit time series model"""
        
        if self.method == "prophet" or self.method == "auto":
            try:
                from prophet import Prophet
                self.model_ = Prophet(
                    yearly_seasonality=True,
                    weekly_seasonality=True,
                    daily_seasonality=False
                )
                
                # Prepare data for Prophet
                df = pd.DataFrame({
                    'ds': y.index,
                    'y': y.values
                })
                
                if exog is not None:
                    for col in exog.columns:
                        self.model_.add_regressor(col)
                        df[col] = exog[col].values
                
                self.model_.fit(df)
                self.method = "prophet"
                
            except ImportError:
                self.method = "arima"
        
        if self.method == "arima":
            try:
                from pmdarima import auto_arima
                self.model_ = auto_arima(
                    y,
                    exogenous=exog,
                    seasonal=self.seasonality is not None,
                    m=self.seasonality or 1,
                    stepwise=True,
                    suppress_warnings=True
                )
                
            except ImportError:
                # Fallback to simple moving average
                self.method = "moving_average"
                self.model_ = SimpleMovingAverage(window=self.seasonality or 7)
                self.model_.fit(y)
        
        return self
    
    def predict(self, steps: int, exog: Optional[pd.DataFrame] = None) -> np.ndarray:
        """Make predictions"""
        
        if self.method == "prophet":
            # Create future dataframe
            future = self.model_.make_future_dataframe(periods=steps)
            
            if exog is not None:
                for col in exog.columns:
                    # Need to extend exog data for future periods
                    future[col] = np.concatenate([
                        self.model_.history[col].values,
                        exog[col].values[:steps]
                    ])
            
            forecast = self.model_.predict(future)
            return forecast['yhat'].iloc[-steps:].values
            
        elif self.method == "arima":
            return self.model_.predict(n_periods=steps, exogenous=exog)
            
        else:
            # Moving average fallback
            return self.model_.predict(steps)


class SimpleMovingAverage:
    """Simple moving average for fallback"""
    
    def __init__(self, window: int = 7):
        self.window = window
        self.history_ = None
        
    def fit(self, y: pd.Series):
        """Fit moving average"""
        self.history_ = y.values[-self.window:]
        return self
    
    def predict(self, steps: int) -> np.ndarray:
        """Predict using moving average"""
        predictions = []
        history = list(self.history_)
        
        for _ in range(steps):
            pred = np.mean(history[-self.window:])
            predictions.append(pred)
            history.append(pred)
        
        return np.array(predictions)
