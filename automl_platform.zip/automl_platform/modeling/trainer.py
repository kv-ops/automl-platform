"""Model training with HPO"""

import numpy as np
import pandas as pd
from sklearn.model_selection import StratifiedKFold, KFold, TimeSeriesSplit, cross_val_score
from sklearn.metrics import roc_auc_score, accuracy_score, mean_squared_error
from typing import Tuple, Dict, Any, Optional, Union
import time
import warnings
warnings.filterwarnings('ignore')

def train_cv(X: Union[pd.DataFrame, np.ndarray], 
             y: Union[pd.Series, np.ndarray],
             task: str = "classification",
             config: Optional[Dict[str, Any]] = None) -> Tuple[Any, Dict]:
    """
    Train model with cross-validation and HPO
    
    Args:
        X: Features
        y: Target
        task: Task type ('classification', 'regression', 'timeseries')
        config: Training configuration
    
    Returns:
        Tuple of (best_model, training_info)
    """
    from ..config.settings import get_config
    
    # Get config
    if config is None:
        config = get_config().to_dict()
    
    n_trials = config.get('n_trials', 30)
    cv_folds = config.get('cv_folds', 5)
    time_budget = config.get('time_budget', 3600)
    algorithms = config.get('algorithms', ['xgboost', 'lightgbm', 'random_forest'])
    random_state = config.get('random_state', 42)
    
    # Determine task specifics
    if task == "classification":
        if len(np.unique(y)) == 2:
            scoring = 'roc_auc'
            cv = StratifiedKFold(n_splits=cv_folds, shuffle=True, random_state=random_state)
        else:
            scoring = 'accuracy'
            cv = StratifiedKFold(n_splits=cv_folds, shuffle=True, random_state=random_state)
    elif task == "regression":
        scoring = 'neg_mean_squared_error'
        cv = KFold(n_splits=cv_folds, shuffle=True, random_state=random_state)
    elif task == "timeseries":
        scoring = 'neg_mean_squared_error'
        cv = TimeSeriesSplit(n_splits=cv_folds)
    else:
        raise ValueError(f"Unknown task: {task}")
    
    # Try to use Optuna for HPO
    try:
        import optuna
        from optuna.samplers import TPESampler
        from optuna.pruners import MedianPruner
        use_optuna = True
    except ImportError:
        use_optuna = False
        print("Optuna not available, using default parameters")
    
    best_score = -np.inf
    best_model = None
    best_params = {}
    training_history = []
    
    start_time = time.time()
    
    if use_optuna:
        # Optuna HPO
        from .search_space import get_search_space
        
        def objective(trial):
            # Check time budget
            if time.time() - start_time > time_budget:
                trial.study.stop()
                return best_score
            
            # Select algorithm
            algo = trial.suggest_categorical('algorithm', algorithms)
            
            # Get hyperparameters
            params = get_search_space(algo, trial)
            
            # Create model
            if algo == 'xgboost':
                try:
                    from xgboost import XGBClassifier, XGBRegressor
                    if task == 'regression':
                        model = XGBRegressor(**params, random_state=random_state)
                    else:
                        model = XGBClassifier(**params, random_state=random_state, use_label_encoder=False, eval_metric='logloss')
                except ImportError:
                    return -np.inf
                    
            elif algo == 'lightgbm':
                try:
                    from lightgbm import LGBMClassifier, LGBMRegressor
                    if task == 'regression':
                        model = LGBMRegressor(**params, random_state=random_state, verbosity=-1)
                    else:
                        model = LGBMClassifier(**params, random_state=random_state, verbosity=-1)
                except ImportError:
                    return -np.inf
                    
            elif algo == 'catboost':
                try:
                    from catboost import CatBoostClassifier, CatBoostRegressor
                    if task == 'regression':
                        model = CatBoostRegressor(**params, random_state=random_state, verbose=False)
                    else:
                        model = CatBoostClassifier(**params, random_state=random_state, verbose=False)
                except ImportError:
                    return -np.inf
                    
            elif algo == 'random_forest':
                from sklearn.ensemble import RandomForestClassifier, RandomForestRegressor
                if task == 'regression':
                    model = RandomForestRegressor(**params, random_state=random_state, n_jobs=-1)
                else:
                    model = RandomForestClassifier(**params, random_state=random_state, n_jobs=-1)
                    
            elif algo == 'logistic_regression':
                from sklearn.linear_model import LogisticRegression
                model = LogisticRegression(**params, random_state=random_state, max_iter=1000)
            
            else:
                return -np.inf
            
            # Cross-validation
            try:
                scores = cross_val_score(model, X, y, cv=cv, scoring=scoring, n_jobs=-1)
                score = scores.mean()
            except Exception as e:
                print(f"Error in trial: {e}")
                return -np.inf
            
            return score
        
        # Create study
        sampler = TPESampler(seed=random_state)
        pruner = MedianPruner(n_startup_trials=5, n_warmup_steps=3)
        study = optuna.create_study(
            direction='maximize',
            sampler=sampler,
            pruner=pruner
        )
        
        # Optimize
        study.optimize(objective, n_trials=n_trials, timeout=time_budget)
        
        # Get best parameters
        best_params = study.best_params
        best_score = study.best_value
        
        # Train final model with best parameters
        algo = best_params.pop('algorithm')
        
    else:
        # Grid search fallback
        algo = algorithms[0] if algorithms else 'random_forest'
        best_params = {}
    
    # Train final model on all data
    if algo == 'xgboost':
        try:
            from xgboost import XGBClassifier, XGBRegressor
            if task == 'regression':
                best_model = XGBRegressor(**best_params, random_state=random_state)
            else:
                best_model = XGBClassifier(**best_params, random_state=random_state, use_label_encoder=False, eval_metric='logloss')
        except ImportError:
            algo = 'random_forest'
            
    if algo == 'lightgbm':
        try:
            from lightgbm import LGBMClassifier, LGBMRegressor
            if task == 'regression':
                best_model = LGBMRegressor(**best_params, random_state=random_state, verbosity=-1)
            else:
                best_model = LGBMClassifier(**best_params, random_state=random_state, verbosity=-1)
        except ImportError:
            algo = 'random_forest'
            
    if algo == 'catboost':
        try:
            from catboost import CatBoostClassifier, CatBoostRegressor
            if task == 'regression':
                best_model = CatBoostRegressor(**best_params, random_state=random_state, verbose=False)
            else:
                best_model = CatBoostClassifier(**best_params, random_state=random_state, verbose=False)
        except ImportError:
            algo = 'random_forest'
            
    if algo == 'random_forest' or best_model is None:
        from sklearn.ensemble import RandomForestClassifier, RandomForestRegressor
        if task == 'regression':
            best_model = RandomForestRegressor(n_estimators=100, random_state=random_state, n_jobs=-1)
        else:
            best_model = RandomForestClassifier(n_estimators=100, random_state=random_state, n_jobs=-1)
    
    if algo == 'logistic_regression':
        from sklearn.linear_model import LogisticRegression
        best_model = LogisticRegression(random_state=random_state, max_iter=1000)
    
    # Fit final model
    best_model.fit(X, y)
    
    # Prepare training info
    training_info = {
        'best_score': best_score,
        'best_params': best_params,
        'algorithm': algo,
        'task': task,
        'cv_folds': cv_folds,
        'n_trials': n_trials if use_optuna else 1,
        'training_time': time.time() - start_time,
        'scoring': scoring
    }
    
    return best_model, training_info
