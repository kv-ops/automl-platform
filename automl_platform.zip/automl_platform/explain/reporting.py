"""Generate comprehensive model reports"""

import json
from typing import Dict, Any, Optional
from datetime import datetime

def build_report(metrics: Dict[str, float],
                importances: Dict[str, float],
                drift: Optional[Dict[str, Any]] = None,
                fairness: Optional[Dict[str, Any]] = None) -> str:
    """Build comprehensive model report in JSON format"""
    
    report = {
        "timestamp": datetime.now().isoformat(),
        "metrics": metrics,
        "feature_importances": importances,
        "model_performance": {
            "status": "good" if metrics.get("accuracy", 0) > 0.7 else "needs_improvement",
            "primary_metric": list(metrics.keys())[0] if metrics else None,
            "primary_value": list(metrics.values())[0] if metrics else None
        }
    }
    
    # Add drift information if available
    if drift:
        report["drift_analysis"] = drift
        report["drift_detected"] = drift.get("drift_detected", False)
    
    # Add fairness information if available
    if fairness:
        report["fairness_analysis"] = fairness
        report["fairness_score"] = fairness.get("fairness_score", None)
    
    # Add recommendations
    recommendations = []
    
    if metrics.get("accuracy", 1.0) < 0.7:
        recommendations.append("Consider feature engineering or hyperparameter tuning")
    
    if drift and drift.get("drift_detected"):
        recommendations.append("Model drift detected - consider retraining")
    
    if fairness and fairness.get("fairness_score", 1.0) < 0.8:
        recommendations.append("Fairness issues detected - review model for bias")
    
    report["recommendations"] = recommendations
    
    return json.dumps(report, indent=2)
