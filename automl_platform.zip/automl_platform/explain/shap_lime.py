"""Model explainability with SHAP and LIME"""

import numpy as np
import pandas as pd
from typing import Any, Dict, Optional, Union

def explain_global(model: Any, X: Union[pd.DataFrame, np.ndarray], 
                  sample_size: int = 100) -> Dict[str, Any]:
    """
    Global model explanation
    
    Priority: SHAP Tree → SHAP Kernel → feature_importances_ → variance → zeros
    """
    explanation = {"method": None, "importances": {}, "values": None}
    
    # Ensure we have column names
    if isinstance(X, np.ndarray):
        feature_names = [f"feature_{i}" for i in range(X.shape[1])]
    else:
        feature_names = list(X.columns)
    
    # Try SHAP Tree Explainer first
    try:
        import shap
        
        # Check if model is tree-based
        if hasattr(model, 'booster') or type(model).__name__ in ['RandomForestClassifier', 'RandomForestRegressor', 
                                                                  'XGBClassifier', 'XGBRegressor',
                                                                  'LGBMClassifier', 'LGBMRegressor']:
            explainer = shap.TreeExplainer(model)
            X_sample = X[:sample_size] if len(X) > sample_size else X
            shap_values = explainer.shap_values(X_sample)
            
            # Handle multi-class output
            if isinstance(shap_values, list):
                shap_values = shap_values[0]
            
            # Calculate mean absolute SHAP values
            importances = np.abs(shap_values).mean(axis=0)
            
            explanation["method"] = "shap_tree"
            explanation["importances"] = dict(zip(feature_names, importances))
            explanation["values"] = shap_values
            
            return explanation
            
    except Exception:
        pass
    
    # Try SHAP Kernel Explainer
    try:
        import shap
        
        X_sample = X[:sample_size] if len(X) > sample_size else X
        
        # Create background data
        if len(X) > 100:
            background = shap.sample(X, 100)
        else:
            background = X
        
        explainer = shap.KernelExplainer(model.predict, background)
        shap_values = explainer.shap_values(X_sample[:10])  # Limited samples for kernel
        
        if isinstance(shap_values, list):
            shap_values = shap_values[0]
        
        importances = np.abs(shap_values).mean(axis=0)
        
        explanation["method"] = "shap_kernel"
        explanation["importances"] = dict(zip(feature_names, importances))
        explanation["values"] = shap_values
        
        return explanation
        
    except Exception:
        pass
    
    # Try feature_importances_
    if hasattr(model, 'feature_importances_'):
        importances = model.feature_importances_
        explanation["method"] = "feature_importances"
        explanation["importances"] = dict(zip(feature_names, importances))
        return explanation
    
    # Try coefficients (for linear models)
    if hasattr(model, 'coef_'):
        if len(model.coef_.shape) == 1:
            importances = np.abs(model.coef_)
        else:
            importances = np.abs(model.coef_).mean(axis=0)
        
        explanation["method"] = "coefficients"
        explanation["importances"] = dict(zip(feature_names, importances))
        return explanation
    
    # Fallback to variance
    if isinstance(X, pd.DataFrame):
        importances = X.var().values
    else:
        importances = np.var(X, axis=0)
    
    # Normalize
    if importances.sum() > 0:
        importances = importances / importances.sum()
    
    explanation["method"] = "variance"
    explanation["importances"] = dict(zip(feature_names, importances))
    
    return explanation

def explain_local(model: Any, X: Union[pd.DataFrame, np.ndarray], 
                 instance_idx: int) -> Dict[str, Any]:
    """
    Local instance explanation
    
    Priority: SHAP → LIME → delta naive → zeros
    """
    explanation = {"method": None, "importances": {}, "values": None}
    
    # Ensure we have column names
    if isinstance(X, np.ndarray):
        feature_names = [f"feature_{i}" for i in range(X.shape[1])]
        instance = X[instance_idx:instance_idx+1]
    else:
        feature_names = list(X.columns)
        instance = X.iloc[instance_idx:instance_idx+1]
    
    # Try SHAP first
    try:
        import shap
        
        # Try Tree Explainer
        if hasattr(model, 'booster') or type(model).__name__ in ['RandomForestClassifier', 'RandomForestRegressor',
                                                                  'XGBClassifier', 'XGBRegressor',
                                                                  'LGBMClassifier', 'LGBMRegressor']:
            explainer = shap.TreeExplainer(model)
            shap_values = explainer.shap_values(instance)
            
            if isinstance(shap_values, list):
                shap_values = shap_values[0]
            
            if len(shap_values.shape) > 1:
                shap_values = shap_values[0]
            
            explanation["method"] = "shap"
            explanation["importances"] = dict(zip(feature_names, shap_values))
            explanation["values"] = shap_values
            
            return explanation
            
    except Exception:
        pass
    
    # Try LIME
    try:
        import lime
        import lime.lime_tabular
        
        explainer = lime.lime_tabular.LimeTabularExplainer(
            X if isinstance(X, np.ndarray) else X.values,
            feature_names=feature_names,
            mode='classification' if hasattr(model, 'predict_proba') else 'regression'
        )
        
        if hasattr(model, 'predict_proba'):
            exp = explainer.explain_instance(
                instance[0] if isinstance(instance, np.ndarray) else instance.values[0],
                model.predict_proba,
                num_features=len(feature_names)
            )
        else:
            exp = explainer.explain_instance(
                instance[0] if isinstance(instance, np.ndarray) else instance.values[0],
                model.predict,
                num_features=len(feature_names)
            )
        
        # Extract feature importances
        importances = dict(exp.as_list())
        
        explanation["method"] = "lime"
        explanation["importances"] = importances
        
        return explanation
        
    except Exception:
        pass
    
    # Fallback to delta naive
    try:
        base_pred = model.predict(instance)[0]
        importances = {}
        
        for i, feature in enumerate(feature_names):
            # Perturb feature
            perturbed = instance.copy()
            if isinstance(perturbed, pd.DataFrame):
                mean_val = X[feature].mean()
                perturbed.iloc[0, i] = mean_val
            else:
                mean_val = X[:, i].mean()
                perturbed[0, i] = mean_val
            
            # Calculate delta
            perturbed_pred = model.predict(perturbed)[0]
            delta = base_pred - perturbed_pred
            importances[feature] = float(delta)
        
        explanation["method"] = "delta"
        explanation["importances"] = importances
        
        return explanation
        
    except Exception:
        pass
    
    # Fallback to zeros
    explanation["method"] = "zeros"
    explanation["importances"] = {feature: 0.0 for feature in feature_names}
    
    return explanation
