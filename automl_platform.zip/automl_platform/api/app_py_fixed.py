"""FastAPI application with all endpoints - VERSION CORRIGÉE"""

from fastapi import FastAPI, HTTPException, BackgroundTasks
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from typing import Dict, Any, List, Optional
import pandas as pd
import numpy as np
import logging
from datetime import datetime
import os
import uuid
import json
from pathlib import Path

from ..modeling.utils import load_model, predict, predict_proba
from ..config.settings import get_config
from ..explain.shap_lime import explain_global, explain_local
from ..monitoring.drift import check_drift
from ..monitoring.quality import check_data_quality

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

app = FastAPI(title="AutoML Platform API", version="2.0.0")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Global state
metrics = {
    "requests": 0,
    "errors": 0,
    "start_time": datetime.now()
}

config = get_config()
MODEL_PATH = config.model_path
_model_cache = {"model": None, "loaded_at": None, "hash": None}
_reference_data = None
_feature_defaults = None  # NOUVEAU: stockage des valeurs par défaut

# Pydantic models
class PredictionRequest(BaseModel):
    features: Dict[str, Any]
    explain: bool = False
    request_id: Optional[str] = None

class BatchPredictionRequest(BaseModel):
    data: List[Dict[str, Any]]
    explain: bool = False
    request_id: Optional[str] = None

class DriftCheckRequest(BaseModel):
    current_data: List[Dict[str, Any]]
    reference_data: Optional[List[Dict[str, Any]]] = None
    threshold: float = 0.1
    method: str = "ks"

def load_feature_defaults():
    """Charger les valeurs par défaut des features depuis un fichier"""
    global _feature_defaults
    defaults_path = Path(config.storage_path) / "feature_defaults.json"
    
    if defaults_path.exists():
        with open(defaults_path, 'r') as f:
            _feature_defaults = json.load(f)
            logger.info(f"Loaded feature defaults from {defaults_path}")
    else:
        # Valeurs par défaut raisonnables si pas de fichier
        _feature_defaults = {
            "default_numeric": 0.5,  # Médiane typique normalisée
            "default_categorical": "unknown"
        }
        logger.warning("No feature defaults file found, using generic defaults")

def get_or_load_model():
    """Load model with caching and hash verification"""
    global _model_cache
    
    if _model_cache["model"] is not None:
        cache_age = (datetime.now() - _model_cache["loaded_at"]).total_seconds()
        if cache_age < 3600:  # 1 hour cache
            # CORRECTION: Vérifier que ce n'est pas le modèle dummy
            if _model_cache.get("hash") == "dummy":
                logger.warning("Dummy model in cache, attempting to reload real model")
            else:
                return _model_cache["model"]
    
    try:
        model = load_model(MODEL_PATH)
        _model_cache = {
            "model": model,
            "loaded_at": datetime.now(),
            "hash": "real_model"  # Marquer comme vrai modèle
        }
        logger.info(f"Model loaded from {MODEL_PATH}")
        
        # Charger les valeurs par défaut des features
        load_feature_defaults()
        
        return model
        
    except Exception as e:
        # CORRECTION: Ne PAS utiliser de modèle dummy en production
        logger.error(f"Failed to load model from {MODEL_PATH}: {e}")
        
        # Option 1: Lever une exception pour forcer le chargement d'un vrai modèle
        raise HTTPException(
            status_code=503,
            detail=f"Model not available. Please ensure {MODEL_PATH} exists and is valid."
        )
        
        # Option 2 (décommentez si vous voulez vraiment un fallback):
        # return create_fallback_model()

def create_fallback_model():
    """Créer un modèle de fallback basé sur des règles simples"""
    # CORRECTION: Au lieu d'un modèle aléatoire, créer un modèle basé sur des règles
    logger.warning("Creating rule-based fallback model")
    
    class RuleBasedModel:
        def __init__(self):
            self.n_features_in_ = 10  # Nombre attendu de features
            
        def predict(self, X):
            """Prédiction basée sur des règles simples"""
            predictions = []
            for idx in range(len(X)):
                row = X.iloc[idx] if hasattr(X, 'iloc') else X[idx]
                
                # Règles simples basées sur des indices de richesse
                score = 0
                
                # Rechercher des indicateurs de richesse dans les noms de colonnes
                for col in X.columns if hasattr(X, 'columns') else range(len(row)):
                    col_name = str(col).lower()
                    value = row[col] if hasattr(row, '__getitem__') else row
                    
                    if 'income' in col_name or 'revenue' in col_name or 'salary' in col_name:
                        score += float(value) if value > 0 else -1
                    elif 'wealth' in col_name or 'rich' in col_name:
                        score += float(value) if value > 0 else -1
                    elif 'asset' in col_name:
                        score += float(value) * 0.5 if value > 0 else 0
                
                # Prédiction: 1 si score positif (tendance à acheter)
                predictions.append(1 if score > 0 else 0)
            
            return np.array(predictions)
        
        def predict_proba(self, X):
            """Probabilités basées sur les règles"""
            preds = self.predict(X)
            probas = []
            for pred in preds:
                if pred == 1:
                    probas.append([0.2, 0.8])  # 80% de chance d'achat
                else:
                    probas.append([0.8, 0.2])  # 20% de chance d'achat
            return np.array(probas)
    
    return RuleBasedModel()

def handle_missing_features(df: pd.DataFrame, expected_features: int, 
                           feature_names: Optional[List[str]] = None) -> pd.DataFrame:
    """
    CORRECTION PRINCIPALE: Gérer les features manquantes intelligemment
    """
    current_features = len(df.columns)
    
    if current_features < expected_features:
        logger.warning(f"Missing {expected_features - current_features} features")
        
        # Stratégie 1: Utiliser les valeurs par défaut stockées
        if _feature_defaults and feature_names:
            for i in range(current_features, expected_features):
                if i < len(feature_names):
                    feature_name = feature_names[i]
                    if feature_name in _feature_defaults:
                        df[feature_name] = _feature_defaults[feature_name]
                    else:
                        # Pour les features numériques, utiliser la médiane
                        df[f'feature_{i}'] = _feature_defaults.get("default_numeric", 0.5)
                else:
                    df[f'feature_{i}'] = _feature_defaults.get("default_numeric", 0.5)
        
        # Stratégie 2: Utiliser des valeurs neutres (pas zéro!)
        else:
            for i in range(current_features, expected_features):
                # IMPORTANT: Utiliser 0.5 (valeur médiane normalisée) au lieu de 0
                # 0 pourrait signifier "pauvre" alors que 0.5 est neutre
                df[f'feature_{i}'] = 0.5
        
        logger.info(f"Padded dataframe with neutral values (0.5), new shape: {df.shape}")
    
    elif current_features > expected_features:
        # Truncate
        df = df.iloc[:, :expected_features]
        logger.warning(f"Truncated dataframe to {expected_features} features")
    
    return df

@app.get("/")
def root():
    """Root endpoint"""
    return {
        "message": "AutoML Platform API",
        "version": "2.0.0",
        "status": "ready",
        "endpoints": ["/health", "/predict", "/predict_batch", "/check_drift", "/metrics", "/reload_model"],
        "model_status": "loaded" if _model_cache["model"] is not None else "not_loaded",
        "model_type": _model_cache.get("hash", "unknown")
    }

@app.get("/health")
def health():
    """Health check endpoint"""
    uptime = (datetime.now() - metrics["start_time"]).total_seconds()
    
    # CORRECTION: Avertir si modèle dummy
    model_warning = None
    if _model_cache.get("hash") == "dummy":
        model_warning = "WARNING: Using dummy model, predictions unreliable!"
    
    return {
        "status": "healthy" if model_warning is None else "degraded",
        "model_path": MODEL_PATH,
        "uptime_seconds": uptime,
        "requests_served": metrics["requests"],
        "error_rate": metrics["errors"] / max(metrics["requests"], 1),
        "model_loaded": _model_cache["model"] is not None,
        "model_type": _model_cache.get("hash", "unknown"),
        "warning": model_warning,
        "timestamp": datetime.now().isoformat()
    }

@app.post("/predict")
async def predict_endpoint(request: PredictionRequest):
    """Single prediction endpoint with explain"""
    request_id = request.request_id or str(uuid.uuid4())
    metrics["requests"] += 1
    
    try:
        model = get_or_load_model()
        
        # CORRECTION: Avertissement si données importantes manquent
        important_features = ['income', 'wealth', 'revenue', 'salary', 'rich', 'poor']
        missing_important = []
        for feat in important_features:
            if any(feat in k.lower() for k in request.features.keys()):
                continue
            missing_important.append(feat)
        
        if missing_important:
            logger.warning(f"Important features might be missing: {missing_important}")
        
        df = pd.DataFrame([request.features])
        
        # Handle different input sizes avec la fonction corrigée
        if hasattr(model, 'n_features_in_'):
            expected_features = model.n_features_in_
            df = handle_missing_features(df, expected_features)
        
        prediction = predict(model, df)[0]
        
        response = {
            "prediction": prediction.item() if hasattr(prediction, 'item') else prediction,
            "request_id": request_id,
            "timestamp": datetime.now().isoformat(),
            "model_type": _model_cache.get("hash", "unknown")
        }
        
        # Ajouter un avertissement si features manquantes
        if hasattr(model, 'n_features_in_') and len(request.features) < model.n_features_in_:
            response["warning"] = f"Input had {len(request.features)} features, model expects {model.n_features_in_}. Defaults were used."
        
        # Add confidence if available
        if hasattr(model, 'predict_proba'):
            proba = predict_proba(model, df)[0]
            response["confidence"] = float(max(proba))
            response["probabilities"] = proba.tolist()
        
        # Add explanation if requested
        if request.explain:
            try:
                # Global explanation (once)
                global_exp = explain_global(model, df)
                # Local explanation for this instance
                local_exp = explain_local(model, df, 0)
                
                response["explanation"] = {
                    "global": global_exp,
                    "local": local_exp
                }
            except Exception as e:
                logger.warning(f"Explanation failed: {e}")
                response["explanation"] = {"error": str(e)}
        
        return response
        
    except HTTPException:
        raise  # Re-raise HTTP exceptions
    except Exception as e:
        metrics["errors"] += 1
        logger.error(f"Prediction error: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@app.post("/predict_batch")
async def predict_batch_endpoint(request: BatchPredictionRequest):
    """Batch prediction endpoint"""
    request_id = request.request_id or str(uuid.uuid4())
    metrics["requests"] += 1
    
    try:
        model = get_or_load_model()
        df = pd.DataFrame(request.data)
        
        # Handle different input sizes avec la fonction corrigée
        if hasattr(model, 'n_features_in_'):
            expected_features = model.n_features_in_
            df = handle_missing_features(df, expected_features)
        
        predictions = predict(model, df)
        
        results = []
        for i, pred in enumerate(predictions):
            result = {
                "index": i,
                "prediction": pred.item() if hasattr(pred, 'item') else pred
            }
            
            # Add confidence if available
            if hasattr(model, 'predict_proba'):
                proba = predict_proba(model, df.iloc[[i]])[0]
                result["confidence"] = float(max(proba))
            
            results.append(result)
        
        response = {
            "request_id": request_id,
            "timestamp": datetime.now().isoformat(),
            "predictions": results,
            "model_type": _model_cache.get("hash", "unknown")
        }
        
        # Avertissement si features manquantes
        if hasattr(model, 'n_features_in_') and len(df.columns) < model.n_features_in_:
            response["warning"] = f"Input had {len(df.columns)} features, model expects {model.n_features_in_}. Defaults were used."
        
        return response
        
    except HTTPException:
        raise
    except Exception as e:
        metrics["errors"] += 1
        logger.error(f"Batch prediction error: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@app.post("/check_drift")
async def check_drift_endpoint(request: DriftCheckRequest):
    """Check for data drift"""
    try:
        current_df = pd.DataFrame(request.current_data)
        
        if request.reference_data:
            reference_df = pd.DataFrame(request.reference_data)
        else:
            # Use stored reference data if available
            if _reference_data is not None:
                reference_df = _reference_data
            else:
                return {
                    "error": "No reference data provided or stored",
                    "timestamp": datetime.now().isoformat()
                }
        
        drift_results = check_drift(
            current_df, 
            reference_df,
            threshold=request.threshold,
            method=request.method
        )
        
        return {
            "drift_results": drift_results,
            "timestamp": datetime.now().isoformat()
        }
        
    except Exception as e:
        logger.error(f"Drift check error: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@app.get("/metrics")
def get_metrics():
    """Get API metrics"""
    uptime = (datetime.now() - metrics["start_time"]).total_seconds()
    return {
        "requests": metrics["requests"],
        "errors": metrics["errors"],
        "error_rate": metrics["errors"] / max(metrics["requests"], 1),
        "uptime_seconds": uptime,
        "start_time": metrics["start_time"].isoformat(),
        "current_time": datetime.now().isoformat(),
        "model_type": _model_cache.get("hash", "unknown")
    }

@app.post("/reload_model")
async def reload_model():
    """Force reload model from disk"""
    global _model_cache
    
    try:
        model = load_model(MODEL_PATH)
        _model_cache = {
            "model": model,
            "loaded_at": datetime.now(),
            "hash": "real_model"  # Marquer comme vrai modèle
        }
        logger.info(f"Model reloaded from {MODEL_PATH}")
        
        # Recharger les valeurs par défaut
        load_feature_defaults()
        
        return {
            "status": "success",
            "message": "Model reloaded successfully",
            "model_type": "real_model",
            "timestamp": datetime.now().isoformat()
        }
        
    except Exception as e:
        logger.error(f"Model reload error: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@app.post("/set_reference_data")
async def set_reference_data(data: List[Dict[str, Any]]):
    """Set reference data for drift detection"""
    global _reference_data
    
    try:
        _reference_data = pd.DataFrame(data)
        
        return {
            "status": "success",
            "message": f"Reference data set with {len(_reference_data)} samples",
            "timestamp": datetime.now().isoformat()
        }
        
    except Exception as e:
        logger.error(f"Set reference data error: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@app.post("/set_feature_defaults")
async def set_feature_defaults(defaults: Dict[str, Any]):
    """Set default values for missing features"""
    global _feature_defaults
    
    try:
        _feature_defaults = defaults
        
        # Sauvegarder dans un fichier
        defaults_path = Path(config.storage_path) / "feature_defaults.json"
        defaults_path.parent.mkdir(parents=True, exist_ok=True)
        
        with open(defaults_path, 'w') as f:
            json.dump(defaults, f, indent=2)
        
        logger.info(f"Feature defaults saved to {defaults_path}")
        
        return {
            "status": "success",
            "message": f"Feature defaults set for {len(defaults)} features",
            "defaults": defaults,
            "timestamp": datetime.now().isoformat()
        }
        
    except Exception as e:
        logger.error(f"Set feature defaults error: {e}")
        raise HTTPException(status_code=500, detail=str(e))