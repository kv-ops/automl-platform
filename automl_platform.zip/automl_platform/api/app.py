"""FastAPI application with all endpoints"""

from fastapi import FastAPI, HTTPException, BackgroundTasks
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from typing import Dict, Any, List, Optional
import pandas as pd
import numpy as np
import logging
from datetime import datetime
import os
import uuid

from ..modeling.utils import load_model, predict, predict_proba
from ..config.settings import get_config
from ..explain.shap_lime import explain_global, explain_local
from ..monitoring.drift import check_drift
from ..monitoring.quality import check_data_quality

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

app = FastAPI(title="AutoML Platform API", version="2.0.0")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Global state
metrics = {
    "requests": 0,
    "errors": 0,
    "start_time": datetime.now()
}

config = get_config()
MODEL_PATH = config.model_path
_model_cache = {"model": None, "loaded_at": None, "hash": None}
_reference_data = None

# Pydantic models
class PredictionRequest(BaseModel):
    features: Dict[str, Any]
    explain: bool = False
    request_id: Optional[str] = None

class BatchPredictionRequest(BaseModel):
    data: List[Dict[str, Any]]
    explain: bool = False
    request_id: Optional[str] = None

class DriftCheckRequest(BaseModel):
    current_data: List[Dict[str, Any]]
    reference_data: Optional[List[Dict[str, Any]]] = None
    threshold: float = 0.1
    method: str = "ks"

def get_or_load_model():
    """Load model with caching and hash verification"""
    global _model_cache
    
    if _model_cache["model"] is not None:
        cache_age = (datetime.now() - _model_cache["loaded_at"]).total_seconds()
        if cache_age < 3600:  # 1 hour cache
            return _model_cache["model"]
    
    try:
        model = load_model(MODEL_PATH)
        _model_cache = {
            "model": model,
            "loaded_at": datetime.now(),
            "hash": None
        }
        logger.info(f"Model loaded from {MODEL_PATH}")
        return model
    except Exception as e:
        logger.warning(f"Failed to load model from {MODEL_PATH}: {e}")
        # Return a dummy model for testing
        from sklearn.ensemble import RandomForestClassifier
        model = RandomForestClassifier(n_estimators=10, random_state=42)
        # Create dummy data for fitting
        X_dummy = np.random.randn(100, 5)
        y_dummy = np.random.randint(0, 2, 100)
        model.fit(X_dummy, y_dummy)
        _model_cache = {
            "model": model,
            "loaded_at": datetime.now(),
            "hash": "dummy"
        }
        logger.info("Using dummy model for testing")
        return model

@app.get("/")
def root():
    """Root endpoint"""
    return {
        "message": "AutoML Platform API",
        "version": "2.0.0",
        "status": "ready",
        "endpoints": ["/health", "/predict", "/predict_batch", "/check_drift", "/metrics", "/reload_model"]
    }

@app.get("/health")
def health():
    """Health check endpoint"""
    uptime = (datetime.now() - metrics["start_time"]).total_seconds()
    return {
        "status": "healthy",
        "model_path": "model.pkl",
        "uptime_seconds": uptime,
        "requests_served": metrics["requests"],
        "error_rate": metrics["errors"] / max(metrics["requests"], 1),
        "model_loaded": _model_cache["model"] is not None,
        "timestamp": datetime.now().isoformat()
    }

@app.post("/predict")
async def predict_endpoint(request: PredictionRequest):
    """Single prediction endpoint with explain"""
    request_id = request.request_id or str(uuid.uuid4())
    metrics["requests"] += 1
    
    try:
        model = get_or_load_model()
        df = pd.DataFrame([request.features])
        
        # Handle different input sizes
        if hasattr(model, 'n_features_in_'):
            expected_features = model.n_features_in_
            if len(df.columns) < expected_features:
                # Pad with zeros
                for i in range(len(df.columns), expected_features):
                    df[f'feature_{i}'] = 0
            elif len(df.columns) > expected_features:
                # Truncate
                df = df.iloc[:, :expected_features]
        
        prediction = predict(model, df)[0]
        
        response = {
            "prediction": prediction.item() if hasattr(prediction, 'item') else prediction,
            "request_id": request_id,
            "timestamp": datetime.now().isoformat()
        }
        
        # Add confidence if available
        if hasattr(model, 'predict_proba'):
            proba = predict_proba(model, df)[0]
            response["confidence"] = float(max(proba))
            response["probabilities"] = proba.tolist()
        
        # Add explanation if requested
        if request.explain:
            try:
                # Global explanation (once)
                global_exp = explain_global(model, df)
                # Local explanation for this instance
                local_exp = explain_local(model, df, 0)
                
                response["explanation"] = {
                    "global": global_exp,
                    "local": local_exp
                }
            except Exception as e:
                logger.warning(f"Explanation failed: {e}")
                response["explanation"] = {"error": str(e)}
        
        return response
        
    except Exception as e:
        metrics["errors"] += 1
        logger.error(f"Prediction error: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@app.post("/predict_batch")
async def predict_batch_endpoint(request: BatchPredictionRequest):
    """Batch prediction endpoint"""
    request_id = request.request_id or str(uuid.uuid4())
    metrics["requests"] += 1
    
    try:
        model = get_or_load_model()
        df = pd.DataFrame(request.data)
        
        # Handle different input sizes
        if hasattr(model, 'n_features_in_'):
            expected_features = model.n_features_in_
            if len(df.columns) < expected_features:
                # Pad with zeros
                for i in range(len(df.columns), expected_features):
                    df[f'feature_{i}'] = 0
            elif len(df.columns) > expected_features:
                # Truncate
                df = df.iloc[:, :expected_features]
        
        predictions = predict(model, df)
        
        results = []
        for i, pred in enumerate(predictions):
            result = {
                "index": i,
                "prediction": pred.item() if hasattr(pred, 'item') else pred
            }
            
            # Add confidence if available
            if hasattr(model, 'predict_proba'):
                proba = predict_proba(model, df.iloc[[i]])[0]
                result["confidence"] = float(max(proba))
            
            results.append(result)
        
        return {
            "request_id": request_id,
            "timestamp": datetime.now().isoformat(),
            "predictions": results
        }
        
    except Exception as e:
        metrics["errors"] += 1
        logger.error(f"Batch prediction error: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@app.post("/check_drift")
async def check_drift_endpoint(request: DriftCheckRequest):
    """Check for data drift"""
    try:
        current_df = pd.DataFrame(request.current_data)
        
        if request.reference_data:
            reference_df = pd.DataFrame(request.reference_data)
        else:
            # Use stored reference data if available
            if _reference_data is not None:
                reference_df = _reference_data
            else:
                return {
                    "error": "No reference data provided or stored",
                    "timestamp": datetime.now().isoformat()
                }
        
        drift_results = check_drift(
            current_df, 
            reference_df,
            threshold=request.threshold,
            method=request.method
        )
        
        return {
            "drift_results": drift_results,
            "timestamp": datetime.now().isoformat()
        }
        
    except Exception as e:
        logger.error(f"Drift check error: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@app.get("/metrics")
def get_metrics():
    """Get API metrics"""
    uptime = (datetime.now() - metrics["start_time"]).total_seconds()
    return {
        "requests": metrics["requests"],
        "errors": metrics["errors"],
        "error_rate": metrics["errors"] / max(metrics["requests"], 1),
        "uptime_seconds": uptime,
        "start_time": metrics["start_time"].isoformat(),
        "current_time": datetime.now().isoformat()
    }

@app.post("/reload_model")
async def reload_model():
    """Force reload model from disk"""
    global _model_cache
    
    try:
        model = load_model(MODEL_PATH)
        _model_cache = {
            "model": model,
            "loaded_at": datetime.now(),
            "hash": None
        }
        logger.info(f"Model reloaded from {MODEL_PATH}")
        
        return {
            "status": "success",
            "message": "Model reloaded successfully",
            "timestamp": datetime.now().isoformat()
        }
        
    except Exception as e:
        logger.error(f"Model reload error: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@app.post("/set_reference_data")
async def set_reference_data(data: List[Dict[str, Any]]):
    """Set reference data for drift detection"""
    global _reference_data
    
    try:
        _reference_data = pd.DataFrame(data)
        
        return {
            "status": "success",
            "message": f"Reference data set with {len(_reference_data)} samples",
            "timestamp": datetime.now().isoformat()
        }
        
    except Exception as e:
        logger.error(f"Set reference data error: {e}")
        raise HTTPException(status_code=500, detail=str(e))
