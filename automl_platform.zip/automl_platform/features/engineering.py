"""Feature engineering module"""

import pandas as pd
import numpy as np
from sklearn.preprocessing import StandardScaler, LabelEncoder, OneHotEncoder
from typing import Optional, List, Dict, Any

class FeatureEngineer:
    """Feature engineering pipeline"""
    
    def __init__(self, 
                 scale_numeric: bool = True,
                 encode_categorical: bool = True,
                 create_interactions: bool = False,
                 max_cardinality: int = 20):
        self.scale_numeric = scale_numeric
        self.encode_categorical = encode_categorical
        self.create_interactions = create_interactions
        self.max_cardinality = max_cardinality
        
        self.scalers_ = {}
        self.encoders_ = {}
        self.feature_names_ = None
        
    def fit(self, X: pd.DataFrame, y: Optional[pd.Series] = None):
        """Fit feature engineering pipeline"""
        self.feature_names_ = list(X.columns)
        
        # Numeric features
        numeric_cols = X.select_dtypes(include=['int64', 'float64']).columns
        if self.scale_numeric and len(numeric_cols) > 0:
            for col in numeric_cols:
                self.scalers_[col] = StandardScaler()
                self.scalers_[col].fit(X[col].values.reshape(-1, 1))
        
        # Categorical features
        categorical_cols = X.select_dtypes(include=['object', 'category']).columns
        if self.encode_categorical and len(categorical_cols) > 0:
            for col in categorical_cols:
                n_unique = X[col].nunique()
                if n_unique <= self.max_cardinality:
                    # Use OneHotEncoder for low cardinality
                    self.encoders_[col] = OneHotEncoder(sparse_output=False, handle_unknown='ignore')
                    self.encoders_[col].fit(X[[col]])
                else:
                    # Use LabelEncoder for high cardinality
                    self.encoders_[col] = LabelEncoder()
                    self.encoders_[col].fit(X[col].fillna('missing'))
        
        return self
    
    def transform(self, X: pd.DataFrame) -> pd.DataFrame:
        """Transform features"""
        X_transformed = X.copy()
        
        # Scale numeric features
        for col, scaler in self.scalers_.items():
            if col in X_transformed.columns:
                X_transformed[col] = scaler.transform(X_transformed[col].values.reshape(-1, 1)).flatten()
        
        # Encode categorical features
        for col, encoder in self.encoders_.items():
            if col in X_transformed.columns:
                if isinstance(encoder, OneHotEncoder):
                    # OneHotEncoder
                    encoded = encoder.transform(X_transformed[[col]])
                    encoded_df = pd.DataFrame(
                        encoded,
                        columns=[f"{col}_{cat}" for cat in encoder.categories_[0]],
                        index=X_transformed.index
                    )
                    X_transformed = pd.concat([X_transformed.drop(columns=[col]), encoded_df], axis=1)
                else:
                    # LabelEncoder
                    X_transformed[col] = encoder.transform(X_transformed[col].fillna('missing'))
        
        # Create interactions
        if self.create_interactions:
            numeric_cols = X_transformed.select_dtypes(include=['int64', 'float64']).columns
            if len(numeric_cols) >= 2:
                # Create top 3 interactions
                for i, col1 in enumerate(numeric_cols[:3]):
                    for col2 in numeric_cols[i+1:4]:
                        X_transformed[f"{col1}_x_{col2}"] = X_transformed[col1] * X_transformed[col2]
        
        return X_transformed
    
    def fit_transform(self, X: pd.DataFrame, y: Optional[pd.Series] = None) -> pd.DataFrame:
        """Fit and transform features"""
        return self.fit(X, y).transform(X)
