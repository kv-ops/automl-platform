"""Feature engineering module - VERSION CORRIGÉE"""

import pandas as pd
import numpy as np
from sklearn.preprocessing import StandardScaler, LabelEncoder, OneHotEncoder, OrdinalEncoder, RobustScaler
from typing import Optional, List, Dict, Any
import logging

logger = logging.getLogger(__name__)

class FeatureEngineer:
    """Feature engineering pipeline with intelligent encoding"""
    
    # Dictionnaire des variables ordinales connues et leur ordre
    ORDINAL_MAPPINGS = {
        # Variables de richesse/revenus
        'wealth': ['poor', 'low', 'medium', 'high', 'rich', 'very_rich', 'millionaire'],
        'income': ['very_low', 'low', 'medium', 'high', 'very_high'],
        'income_level': ['<20k', '20-40k', '40-60k', '60-80k', '80-100k', '100-150k', '150k+'],
        'economic_status': ['poor', 'lower_middle', 'middle', 'upper_middle', 'wealthy', 'rich'],
        'customer_value': ['low', 'medium', 'high', 'vip', 'premium'],
        
        # Variables d'éducation
        'education': ['none', 'primary', 'secondary', 'bachelor', 'master', 'phd'],
        'education_level': ['no_degree', 'high_school', 'some_college', 'bachelor', 'graduate'],
        
        # Variables de satisfaction/rating
        'satisfaction': ['very_dissatisfied', 'dissatisfied', 'neutral', 'satisfied', 'very_satisfied'],
        'rating': ['very_poor', 'poor', 'average', 'good', 'excellent'],
        
        # Variables de fréquence
        'frequency': ['never', 'rarely', 'sometimes', 'often', 'always'],
        'purchase_frequency': ['never', 'rarely', 'occasional', 'regular', 'frequent'],
    }
    
    def __init__(self, 
                 scale_numeric: bool = True,
                 encode_categorical: bool = True,
                 create_interactions: bool = False,
                 max_cardinality: int = 20,
                 use_robust_scaler: bool = True):  # NOUVEAU: RobustScaler pour les outliers
        self.scale_numeric = scale_numeric
        self.encode_categorical = encode_categorical
        self.create_interactions = create_interactions
        self.max_cardinality = max_cardinality
        self.use_robust_scaler = use_robust_scaler
        
        self.scalers_ = {}
        self.encoders_ = {}
        self.feature_names_ = None
        self.feature_stats_ = {}  # NOUVEAU: Statistiques pour le padding intelligent
        
    def _detect_ordinal_column(self, col_name: str, unique_values: List) -> Optional[List]:
        """Détecter si une colonne est ordinale et retourner le mapping"""
        col_lower = col_name.lower()
        
        # Vérifier dans les mappings connus
        for key, mapping in self.ORDINAL_MAPPINGS.items():
            if key in col_lower:
                # Vérifier si les valeurs correspondent
                unique_lower = [str(v).lower() for v in unique_values if pd.notna(v)]
                if any(val in mapping for val in unique_lower):
                    logger.info(f"Detected ordinal column '{col_name}' with mapping type '{key}'")
                    return mapping
        
        # Détection basée sur les valeurs
        unique_str = [str(v).lower() for v in unique_values if pd.notna(v)]
        
        # Patterns de richesse
        wealth_indicators = ['poor', 'rich', 'wealth', 'millionaire', 'high', 'low']
        if any(indicator in ' '.join(unique_str) for indicator in wealth_indicators):
            logger.info(f"Detected wealth-related ordinal column '{col_name}'")
            # Essayer de créer un ordre logique
            if 'poor' in unique_str and 'rich' in unique_str:
                return self._create_custom_ordinal_mapping(unique_values, wealth_related=True)
        
        return None
    
    def _create_custom_ordinal_mapping(self, unique_values: List, wealth_related: bool = False) -> List:
        """Créer un mapping ordinal personnalisé basé sur les valeurs"""
        unique_clean = [v for v in unique_values if pd.notna(v)]
        
        if wealth_related:
            # Ordre pour les variables de richesse
            order_priority = {
                'poor': 0, 'low': 1, 'below_average': 2, 'average': 3, 'medium': 4,
                'above_average': 5, 'high': 6, 'rich': 7, 'wealthy': 8, 
                'very_rich': 9, 'millionaire': 10
            }
            
            # Trier selon la priorité
            sorted_values = sorted(unique_clean, 
                                 key=lambda x: order_priority.get(str(x).lower(), 5))
            return sorted_values
        
        # Par défaut, ordre alphabétique
        return sorted(unique_clean)
        
    def fit(self, X: pd.DataFrame, y: Optional[pd.Series] = None):
        """Fit feature engineering pipeline"""
        self.feature_names_ = list(X.columns)
        
        # Calculer les statistiques pour chaque feature (pour le padding intelligent)
        for col in X.columns:
            if pd.api.types.is_numeric_dtype(X[col]):
                self.feature_stats_[col] = {
                    'mean': X[col].mean(),
                    'median': X[col].median(),
                    'std': X[col].std(),
                    'min': X[col].min(),
                    'max': X[col].max()
                }
            else:
                # Pour les catégorielles, stocker le mode
                mode_val = X[col].mode()[0] if len(X[col].mode()) > 0 else 'unknown'
                self.feature_stats_[col] = {
                    'mode': mode_val,
                    'unique_values': X[col].unique().tolist()
                }
        
        # Numeric features
        numeric_cols = X.select_dtypes(include=['int64', 'float64']).columns
        if self.scale_numeric and len(numeric_cols) > 0:
            for col in numeric_cols:
                # CORRECTION: Détecter les colonnes de richesse/montant pour ne pas les normaliser négativement
                col_lower = col.lower()
                
                # Ne pas normaliser certaines colonnes critiques ou utiliser RobustScaler
                if any(keyword in col_lower for keyword in ['income', 'revenue', 'salary', 'wealth', 'amount', 'price']):
                    # Utiliser RobustScaler pour les variables de richesse (résistant aux outliers)
                    logger.info(f"Using RobustScaler for wealth-related column '{col}'")
                    from sklearn.preprocessing import RobustScaler
                    self.scalers_[col] = RobustScaler()
                elif self.use_robust_scaler:
                    # RobustScaler par défaut (meilleur pour les outliers)
                    self.scalers_[col] = RobustScaler()
                else:
                    # StandardScaler classique
                    self.scalers_[col] = StandardScaler()
                
                self.scalers_[col].fit(X[col].values.reshape(-1, 1))
        
        # Categorical features
        categorical_cols = X.select_dtypes(include=['object', 'category']).columns
        if self.encode_categorical and len(categorical_cols) > 0:
            for col in categorical_cols:
                unique_values = X[col].dropna().unique()
                n_unique = len(unique_values)
                
                # CORRECTION PRINCIPALE: Détecter les variables ordinales
                ordinal_mapping = self._detect_ordinal_column(col, unique_values)
                
                if ordinal_mapping:
                    # Utiliser OrdinalEncoder pour les variables avec un ordre logique
                    logger.info(f"Using OrdinalEncoder for column '{col}'")
                    
                    # Créer le mapping complet en incluant les valeurs présentes
                    full_mapping = []
                    for val in ordinal_mapping:
                        if val in [str(v).lower() for v in unique_values]:
                            full_mapping.append(val)
                    
                    # Ajouter les valeurs non mappées à la fin
                    for val in unique_values:
                        if str(val).lower() not in full_mapping and pd.notna(val):
                            full_mapping.append(val)
                    
                    # Ajouter 'missing' pour les NaN
                    full_mapping.append('missing')
                    
                    self.encoders_[col] = OrdinalEncoder(
                        categories=[full_mapping],
                        handle_unknown='use_encoded_value',
                        unknown_value=-1
                    )
                    
                    # Préparer les données pour fit
                    X_col = X[col].fillna('missing').str.lower() if X[col].dtype == 'object' else X[col].fillna('missing')
                    self.encoders_[col].fit(X_col.values.reshape(-1, 1))
                    
                elif n_unique <= self.max_cardinality:
                    # Use OneHotEncoder for low cardinality non-ordinal
                    logger.info(f"Using OneHotEncoder for column '{col}' ({n_unique} unique values)")
                    self.encoders_[col] = OneHotEncoder(sparse_output=False, handle_unknown='ignore')
                    self.encoders_[col].fit(X[[col]])
                    
                else:
                    # CORRECTION: Pour haute cardinalité, utiliser une technique plus intelligente
                    logger.warning(f"High cardinality column '{col}' ({n_unique} unique values)")
                    
                    # Option 1: Target encoding si y est disponible
                    if y is not None and pd.api.types.is_numeric_dtype(y):
                        logger.info(f"Using target encoding for high cardinality column '{col}'")
                        # Calculer la moyenne de y pour chaque catégorie
                        target_means = {}
                        for value in unique_values:
                            mask = X[col] == value
                            if mask.sum() > 0:
                                target_means[value] = y[mask].mean()
                        
                        # Stocker le mapping
                        self.encoders_[col] = {'type': 'target', 'mapping': target_means, 'default': y.mean()}
                    else:
                        # Option 2: Frequency encoding comme fallback
                        logger.info(f"Using frequency encoding for high cardinality column '{col}'")
                        value_counts = X[col].value_counts()
                        freq_mapping = {val: count/len(X) for val, count in value_counts.items()}
                        self.encoders_[col] = {'type': 'frequency', 'mapping': freq_mapping, 'default': 1/len(X)}
        
        return self
    
    def transform(self, X: pd.DataFrame) -> pd.DataFrame:
        """Transform features"""
        X_transformed = X.copy()
        
        # Scale numeric features
        for col, scaler in self.scalers_.items():
            if col in X_transformed.columns:
                X_transformed[col] = scaler.transform(X_transformed[col].values.reshape(-1, 1)).flatten()
        
        # Encode categorical features
        for col, encoder in self.encoders_.items():
            if col in X_transformed.columns:
                if isinstance(encoder, dict):
                    # Custom encoding (target ou frequency)
                    if encoder['type'] == 'target':
                        X_transformed[col] = X_transformed[col].map(encoder['mapping']).fillna(encoder['default'])
                    elif encoder['type'] == 'frequency':
                        X_transformed[col] = X_transformed[col].map(encoder['mapping']).fillna(encoder['default'])
                        
                elif isinstance(encoder, OrdinalEncoder):
                    # OrdinalEncoder
                    X_col = X_transformed[col].fillna('missing')
                    if X_col.dtype == 'object':
                        X_col = X_col.str.lower()
                    X_transformed[col] = encoder.transform(X_col.values.reshape(-1, 1)).flatten()
                    
                elif isinstance(encoder, OneHotEncoder):
                    # OneHotEncoder
                    encoded = encoder.transform(X_transformed[[col]])
                    encoded_df = pd.DataFrame(
                        encoded,
                        columns=[f"{col}_{cat}" for cat in encoder.categories_[0]],
                        index=X_transformed.index
                    )
                    X_transformed = pd.concat([X_transformed.drop(columns=[col]), encoded_df], axis=1)
                    
                else:
                    # LabelEncoder (ne devrait plus être utilisé)
                    X_transformed[col] = encoder.transform(X_transformed[col].fillna('missing'))
        
        # Create interactions (notamment entre variables de richesse)
        if self.create_interactions:
            numeric_cols = X_transformed.select_dtypes(include=['int64', 'float64']).columns.tolist()
            
            # Prioriser les interactions avec les variables de richesse
            wealth_cols = [col for col in numeric_cols 
                          if any(keyword in col.lower() for keyword in ['income', 'wealth', 'salary', 'revenue'])]
            
            if wealth_cols:
                # Interactions avec les variables de richesse
                for wealth_col in wealth_cols[:2]:  # Limiter à 2 variables de richesse
                    for other_col in numeric_cols[:5]:  # Top 5 autres variables
                        if wealth_col != other_col:
                            interaction_name = f"{wealth_col}_x_{other_col}"
                            if interaction_name not in X_transformed.columns:
                                X_transformed[interaction_name] = X_transformed[wealth_col] * X_transformed[other_col]
                                logger.info(f"Created interaction: {interaction_name}")
            else:
                # Interactions standards si pas de variables de richesse
                if len(numeric_cols) >= 2:
                    for i, col1 in enumerate(numeric_cols[:3]):
                        for col2 in numeric_cols[i+1:4]:
                            X_transformed[f"{col1}_x_{col2}"] = X_transformed[col1] * X_transformed[col2]
        
        return X_transformed
    
    def fit_transform(self, X: pd.DataFrame, y: Optional[pd.Series] = None) -> pd.DataFrame:
        """Fit and transform features"""
        return self.fit(X, y).transform(X)
    
    def get_feature_defaults(self) -> Dict[str, Any]:
        """Retourner les valeurs par défaut pour chaque feature (pour le padding intelligent)"""
        defaults = {}
        
        for col, stats in self.feature_stats_.items():
            if 'median' in stats:
                # Pour les numériques, utiliser la médiane
                defaults[col] = stats['median']
            elif 'mode' in stats:
                # Pour les catégorielles, utiliser le mode
                defaults[col] = stats['mode']
            else:
                defaults[col] = 0.5  # Valeur neutre par défaut
        
        return defaults