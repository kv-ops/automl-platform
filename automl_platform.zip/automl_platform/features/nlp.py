"""NLP feature extraction"""

import pandas as pd
import numpy as np
from sklearn.feature_extraction.text import TfidfVectorizer
from typing import Optional, List, Union

class TextFeatureExtractor:
    """Text feature extraction"""
    
    def __init__(self, 
                 method: str = "tfidf",
                 max_features: int = 100,
                 ngram_range: tuple = (1, 2),
                 min_df: int = 2):
        self.method = method
        self.max_features = max_features
        self.ngram_range = ngram_range
        self.min_df = min_df
        self.vectorizer_ = None
        self.embedder_ = None
        
    def fit(self, texts: Union[List[str], pd.Series]):
        """Fit text feature extractor"""
        if self.method == "tfidf":
            self.vectorizer_ = TfidfVectorizer(
                max_features=self.max_features,
                ngram_range=self.ngram_range,
                min_df=self.min_df,
                stop_words='english'
            )
            self.vectorizer_.fit(texts)
            
        elif self.method == "embeddings":
            # Try to use sentence transformers if available
            try:
                from sentence_transformers import SentenceTransformer
                self.embedder_ = SentenceTransformer('all-MiniLM-L6-v2')
            except ImportError:
                # Fallback to TF-IDF
                print("Sentence transformers not available, falling back to TF-IDF")
                self.method = "tfidf"
                self.vectorizer_ = TfidfVectorizer(
                    max_features=self.max_features,
                    ngram_range=self.ngram_range,
                    min_df=self.min_df
                )
                self.vectorizer_.fit(texts)
        
        return self
    
    def transform(self, texts: Union[List[str], pd.Series]) -> np.ndarray:
        """Transform texts to features"""
        if self.method == "tfidf":
            if self.vectorizer_ is None:
                raise ValueError("Vectorizer not fitted yet")
            return self.vectorizer_.transform(texts).toarray()
            
        elif self.method == "embeddings" and self.embedder_ is not None:
            embeddings = self.embedder_.encode(list(texts))
            # Reduce dimensionality if needed
            if embeddings.shape[1] > self.max_features:
                from sklearn.decomposition import PCA
                pca = PCA(n_components=self.max_features)
                embeddings = pca.fit_transform(embeddings)
            return embeddings
        
        else:
            # Fallback
            if self.vectorizer_ is None:
                raise ValueError("No feature extractor fitted")
            return self.vectorizer_.transform(texts).toarray()
    
    def fit_transform(self, texts: Union[List[str], pd.Series]) -> np.ndarray:
        """Fit and transform texts"""
        return self.fit(texts).transform(texts)
    
    def get_feature_names(self) -> List[str]:
        """Get feature names"""
        if self.method == "tfidf" and self.vectorizer_ is not None:
            return self.vectorizer_.get_feature_names_out().tolist()
        elif self.method == "embeddings":
            return [f"embed_{i}" for i in range(self.max_features)]
        else:
            return []
