"""Feature selection module"""

import pandas as pd
import numpy as np
from sklearn.feature_selection import SelectKBest, f_classif, f_regression, mutual_info_classif, mutual_info_regression
from sklearn.ensemble import RandomForestClassifier, RandomForestRegressor
from typing import Optional, List, Union, Dict

class FeatureSelector:
    """Feature selection methods"""
    
    def __init__(self, 
                 method: str = "importance",
                 k: Union[int, float] = 0.8,
                 task: str = "classification"):
        """
        Initialize feature selector
        
        Args:
            method: Selection method ('importance', 'statistical', 'permutation')
            k: Number of features to select (int) or fraction (float)
            task: Task type ('classification' or 'regression')
        """
        self.method = method
        self.k = k
        self.task = task
        self.selected_features_ = None
        self.scores_ = None
        self.selector_ = None
        
    def fit(self, X: pd.DataFrame, y: pd.Series):
        """Fit feature selector"""
        n_features = X.shape[1]
        
        if isinstance(self.k, float):
            k_features = max(1, int(n_features * self.k))
        else:
            k_features = min(self.k, n_features)
        
        if self.method == "importance":
            # Use tree-based feature importance
            if self.task == "classification":
                model = RandomForestClassifier(n_estimators=100, random_state=42, n_jobs=-1)
            else:
                model = RandomForestRegressor(n_estimators=100, random_state=42, n_jobs=-1)
            
            model.fit(X, y)
            importances = model.feature_importances_
            
            # Select top k features
            indices = np.argsort(importances)[::-1][:k_features]
            self.selected_features_ = X.columns[indices].tolist()
            self.scores_ = dict(zip(X.columns, importances))
            
        elif self.method == "statistical":
            # Use statistical tests
            if self.task == "classification":
                score_func = f_classif
            else:
                score_func = f_regression
            
            selector = SelectKBest(score_func=score_func, k=k_features)
            selector.fit(X, y)
            
            self.selector_ = selector
            self.selected_features_ = X.columns[selector.get_support()].tolist()
            self.scores_ = dict(zip(X.columns, selector.scores_))
            
        elif self.method == "permutation":
            # Permutation importance (simplified)
            if self.task == "classification":
                model = RandomForestClassifier(n_estimators=50, random_state=42, n_jobs=-1)
            else:
                model = RandomForestRegressor(n_estimators=50, random_state=42, n_jobs=-1)
            
            model.fit(X, y)
            baseline_score = model.score(X, y)
            
            importances = []
            for col in X.columns:
                X_perm = X.copy()
                X_perm[col] = np.random.permutation(X_perm[col])
                perm_score = model.score(X_perm, y)
                importance = baseline_score - perm_score
                importances.append(importance)
            
            importances = np.array(importances)
            indices = np.argsort(importances)[::-1][:k_features]
            
            self.selected_features_ = X.columns[indices].tolist()
            self.scores_ = dict(zip(X.columns, importances))
        
        else:
            raise ValueError(f"Unknown method: {self.method}")
        
        return self
    
    def transform(self, X: pd.DataFrame) -> pd.DataFrame:
        """Transform features"""
        if self.selected_features_ is None:
            raise ValueError("Selector not fitted yet")
        
        return X[self.selected_features_]
    
    def fit_transform(self, X: pd.DataFrame, y: pd.Series) -> pd.DataFrame:
        """Fit and transform features"""
        return self.fit(X, y).transform(X)
    
    def get_feature_scores(self) -> Dict[str, float]:
        """Get feature scores"""
        if self.scores_ is None:
            raise ValueError("Selector not fitted yet")
        return self.scores_
