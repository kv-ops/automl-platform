"""Data I/O operations"""

import pandas as pd
import numpy as np
from pathlib import Path
from typing import Tuple, List, Optional, Union
import json

def load_data(filepath: Union[str, Path], **kwargs) -> pd.DataFrame:
    """Load data from various formats"""
    filepath = Path(filepath)
    
    if not filepath.exists():
        raise FileNotFoundError(f"File not found: {filepath}")
    
    suffix = filepath.suffix.lower()
    
    if suffix == '.csv':
        return pd.read_csv(filepath, **kwargs)
    elif suffix == '.parquet':
        return pd.read_parquet(filepath, **kwargs)
    elif suffix == '.json':
        return pd.read_json(filepath, **kwargs)
    elif suffix in ['.xlsx', '.xls']:
        return pd.read_excel(filepath, **kwargs)
    else:
        raise ValueError(f"Unsupported file format: {suffix}")

def save_data(df: pd.DataFrame, filepath: Union[str, Path], **kwargs) -> None:
    """Save data to various formats"""
    filepath = Path(filepath)
    filepath.parent.mkdir(parents=True, exist_ok=True)
    
    suffix = filepath.suffix.lower()
    
    if suffix == '.csv':
        df.to_csv(filepath, index=False, **kwargs)
    elif suffix == '.parquet':
        df.to_parquet(filepath, index=False, **kwargs)
    elif suffix == '.json':
        df.to_json(filepath, **kwargs)
    elif suffix in ['.xlsx', '.xls']:
        df.to_excel(filepath, index=False, **kwargs)
    else:
        raise ValueError(f"Unsupported file format: {suffix}")

def validate_dataframe(df: pd.DataFrame, required_columns: Optional[List[str]] = None) -> bool:
    """Validate DataFrame structure"""
    if df.empty:
        raise ValueError("DataFrame is empty")
    
    if required_columns:
        missing = set(required_columns) - set(df.columns)
        if missing:
            raise ValueError(f"Missing required columns: {missing}")
    
    # Check for all null columns
    null_cols = df.columns[df.isnull().all()].tolist()
    if null_cols:
        print(f"Warning: Columns with all null values: {null_cols}")
    
    # Check for duplicate columns
    duplicate_cols = df.columns[df.columns.duplicated()].tolist()
    if duplicate_cols:
        raise ValueError(f"Duplicate column names found: {duplicate_cols}")
    
    return True

def split_features_target(df: pd.DataFrame, target_column: str) -> Tuple[pd.DataFrame, pd.Series]:
    """Split DataFrame into features and target"""
    if target_column not in df.columns:
        raise ValueError(f"Target column '{target_column}' not found in DataFrame")
    
    X = df.drop(columns=[target_column])
    y = df[target_column]
    
    return X, y
