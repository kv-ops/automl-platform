"""Enhanced platform configuration"""

from dataclasses import dataclass, field
from typing import List, Optional, Dict, Any
from pathlib import Path

@dataclass
class EnhancedPlatformConfig:
    """Enhanced configuration for AutoML platform"""
    
    # Core settings
    n_trials: int = 30
    cv_folds: int = 5
    drift_threshold: float = 0.1
    n_jobs: int = -1
    time_budget: int = 3600
    random_state: int = 42
    
    # Privacy & compliance
    privacy_email: str = "privacy@automl-platform.com"
    storage_path: str = "./automl_storage"
    model_path: str = "model.pkl"
    
    # Training
    algorithms: List[str] = field(default_factory=lambda: ["xgboost", "lightgbm", "random_forest"])
    early_stopping_rounds: int = 50
    validation_fraction: float = 0.2
    
    # Monitoring
    alert_threshold: float = 0.95
    quality_threshold: float = 0.8
    
    # Fairness
    protected_attributes: List[str] = field(default_factory=list)
    fairness_threshold: float = 0.8
    
    # Feature engineering
    max_features: int = 100
    feature_selection_method: str = "importance"
    
    # API
    api_host: str = "0.0.0.0"
    api_port: int = 8000
    api_workers: int = 4
    
    def validate(self) -> bool:
        """Validate configuration"""
        assert self.n_trials > 0, "n_trials must be positive"
        assert 0 < self.cv_folds <= 20, "cv_folds must be between 1 and 20"
        assert 0 <= self.drift_threshold <= 1, "drift_threshold must be between 0 and 1"
        assert self.time_budget > 0, "time_budget must be positive"
        assert 0 < self.validation_fraction < 1, "validation_fraction must be between 0 and 1"
        
        # Create storage path if needed
        Path(self.storage_path).mkdir(parents=True, exist_ok=True)
        
        return True
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary"""
        return {
            "n_trials": self.n_trials,
            "cv_folds": self.cv_folds,
            "drift_threshold": self.drift_threshold,
            "n_jobs": self.n_jobs,
            "time_budget": self.time_budget,
            "random_state": self.random_state,
            "privacy_email": self.privacy_email,
            "storage_path": self.storage_path,
            "model_path": self.model_path,
            "algorithms": self.algorithms,
            "early_stopping_rounds": self.early_stopping_rounds,
            "validation_fraction": self.validation_fraction,
            "alert_threshold": self.alert_threshold,
            "quality_threshold": self.quality_threshold,
            "protected_attributes": self.protected_attributes,
            "fairness_threshold": self.fairness_threshold,
            "max_features": self.max_features,
            "feature_selection_method": self.feature_selection_method,
            "api_host": self.api_host,
            "api_port": self.api_port,
            "api_workers": self.api_workers
        }

# Singleton instance
_config_instance = None

def get_config() -> EnhancedPlatformConfig:
    """Get configuration singleton"""
    global _config_instance
    if _config_instance is None:
        _config_instance = EnhancedPlatformConfig()
        _config_instance.validate()
    return _config_instance

def set_config(config: EnhancedPlatformConfig) -> None:
    """Set configuration singleton"""
    global _config_instance
    config.validate()
    _config_instance = config
