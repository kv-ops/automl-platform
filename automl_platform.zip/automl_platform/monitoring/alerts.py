"""Alert system for monitoring"""

import json
from datetime import datetime
from pathlib import Path
from typing import Dict, Any, List, Optional

class AlertManager:
    """Manage monitoring alerts"""
    
    def __init__(self, alert_file: str = "alerts.json"):
        self.alert_file = Path(alert_file)
        self.alerts = []
        self._load_alerts()
    
    def _load_alerts(self):
        """Load existing alerts"""
        if self.alert_file.exists():
            with open(self.alert_file, 'r') as f:
                self.alerts = json.load(f)
    
    def _save_alerts(self):
        """Save alerts to file"""
        with open(self.alert_file, 'w') as f:
            json.dump(self.alerts, f, indent=2)
    
    def add_alert(self, alert_type: str, message: str, 
                 severity: str = "warning", metadata: Optional[Dict] = None):
        """Add new alert"""
        alert = {
            "id": len(self.alerts) + 1,
            "timestamp": datetime.now().isoformat(),
            "type": alert_type,
            "message": message,
            "severity": severity,
            "metadata": metadata or {},
            "resolved": False
        }
        
        self.alerts.append(alert)
        self._save_alerts()
        
        return alert
    
    def get_active_alerts(self) -> List[Dict]:
        """Get unresolved alerts"""
        return [a for a in self.alerts if not a.get("resolved", False)]
    
    def resolve_alert(self, alert_id: int):
        """Mark alert as resolved"""
        for alert in self.alerts:
            if alert["id"] == alert_id:
                alert["resolved"] = True
                alert["resolved_at"] = datetime.now().isoformat()
                self._save_alerts()
                return True
        return False
    
    def check_thresholds(self, metrics: Dict[str, float], 
                        thresholds: Dict[str, float]) -> List[Dict]:
        """Check metrics against thresholds and create alerts"""
        new_alerts = []
        
        for metric, value in metrics.items():
            if metric in thresholds:
                threshold = thresholds[metric]
                
                if value > threshold:
                    alert = self.add_alert(
                        alert_type="threshold_exceeded",
                        message=f"{metric} exceeded threshold: {value:.3f} > {threshold}",
                        severity="warning" if value < threshold * 1.5 else "critical",
                        metadata={"metric": metric, "value": value, "threshold": threshold}
                    )
                    new_alerts.append(alert)
        
        return new_alerts
