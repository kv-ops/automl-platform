"""Data drift detection"""

import numpy as np
import pandas as pd
from scipy import stats
from typing import Dict, Any, Optional, Union

def check_drift(X_current: pd.DataFrame, 
               X_reference: pd.DataFrame,
               threshold: float = 0.1,
               method: str = "ks") -> Dict[str, Any]:
    """
    Check for data drift between current and reference data
    
    Methods: KS test, Wasserstein distance, or JSD
    """
    results = {
        "drift_detected": False,
        "method": method,
        "threshold": threshold,
        "feature_drift": {},
        "segment_drift": {}
    }
    
    # Check each feature
    for col in X_current.columns:
        if col not in X_reference.columns:
            continue
        
        current_vals = X_current[col].dropna()
        reference_vals = X_reference[col].dropna()
        
        if len(current_vals) == 0 or len(reference_vals) == 0:
            continue
        
        # Compute drift score based on method
        if method == "ks":
            # Kolmogorov-Smirnov test
            if pd.api.types.is_numeric_dtype(current_vals):
                statistic, p_value = stats.ks_2samp(current_vals, reference_vals)
                drift_score = statistic
            else:
                # For categorical, use chi-square
                current_counts = current_vals.value_counts()
                reference_counts = reference_vals.value_counts()
                
                # Align categories
                all_categories = set(current_counts.index) | set(reference_counts.index)
                current_aligned = pd.Series([current_counts.get(cat, 0) for cat in all_categories])
                reference_aligned = pd.Series([reference_counts.get(cat, 0) for cat in all_categories])
                
                if len(all_categories) > 1:
                    chi2, p_value = stats.chisquare(current_aligned + 1, reference_aligned + 1)
                    drift_score = min(1.0, chi2 / 100)  # Normalize
                else:
                    drift_score = 0.0
        
        elif method == "wasserstein":
            # Wasserstein distance
            if pd.api.types.is_numeric_dtype(current_vals):
                drift_score = stats.wasserstein_distance(current_vals, reference_vals)
                # Normalize
                max_val = max(current_vals.max(), reference_vals.max())
                min_val = min(current_vals.min(), reference_vals.min())
                if max_val > min_val:
                    drift_score = drift_score / (max_val - min_val)
            else:
                drift_score = 0.0
        
        elif method == "jsd":
            # Jensen-Shannon Divergence
            if pd.api.types.is_numeric_dtype(current_vals):
                # Bin numeric values
                bins = np.histogram_bin_edges(np.concatenate([current_vals, reference_vals]), bins=20)
                current_hist, _ = np.histogram(current_vals, bins=bins)
                reference_hist, _ = np.histogram(reference_vals, bins=bins)
                
                # Normalize
                current_hist = current_hist / current_hist.sum()
                reference_hist = reference_hist / reference_hist.sum()
                
                # Calculate JSD
                m = (current_hist + reference_hist) / 2
                divergence_current = stats.entropy(current_hist + 1e-10, m + 1e-10)
                divergence_reference = stats.entropy(reference_hist + 1e-10, m + 1e-10)
                drift_score = (divergence_current + divergence_reference) / 2
            else:
                # For categorical
                current_probs = current_vals.value_counts(normalize=True)
                reference_probs = reference_vals.value_counts(normalize=True)
                
                # Align categories
                all_categories = set(current_probs.index) | set(reference_probs.index)
                current_aligned = pd.Series([current_probs.get(cat, 0) for cat in all_categories])
                reference_aligned = pd.Series([reference_probs.get(cat, 0) for cat in all_categories])
                
                m = (current_aligned + reference_aligned) / 2
                divergence_current = stats.entropy(current_aligned + 1e-10, m + 1e-10)
                divergence_reference = stats.entropy(reference_aligned + 1e-10, m + 1e-10)
                drift_score = (divergence_current + divergence_reference) / 2
        
        else:
            drift_score = 0.0
        
        results["feature_drift"][col] = {
            "score": float(drift_score),
            "drifted": drift_score > threshold
        }
        
        if drift_score > threshold:
            results["drift_detected"] = True
    
    # Check segment drift (for up to 2 categorical features)
    categorical_cols = X_current.select_dtypes(include=['object', 'category']).columns[:2]
    
    for col in categorical_cols:
        if col not in X_reference.columns:
            continue
        
        segments = X_current[col].unique()
        segment_scores = {}
        
        for segment in segments:
            if segment not in X_reference[col].values:
                segment_scores[str(segment)] = 1.0
                continue
            
            current_segment = X_current[X_current[col] == segment]
            reference_segment = X_reference[X_reference[col] == segment]
            
            if len(current_segment) < 10 or len(reference_segment) < 10:
                continue
            
            # Simple drift check on first numeric column
            numeric_cols = current_segment.select_dtypes(include=['number']).columns
            if len(numeric_cols) > 0:
                num_col = numeric_cols[0]
                statistic, _ = stats.ks_2samp(
                    current_segment[num_col].dropna(),
                    reference_segment[num_col].dropna()
                )
                segment_scores[str(segment)] = float(statistic)
        
        if segment_scores:
            results["segment_drift"][col] = segment_scores
    
    # Overall drift score
    if results["feature_drift"]:
        drift_scores = [f["score"] for f in results["feature_drift"].values()]
        results["overall_drift_score"] = float(np.mean(drift_scores))
    else:
        results["overall_drift_score"] = 0.0
    
    return results
