"""Data quality monitoring"""

import numpy as np
import pandas as pd
from typing import Dict, Any, List, Optional

def check_data_quality(df: pd.DataFrame, 
                      reference_df: Optional[pd.DataFrame] = None) -> Dict[str, Any]:
    """Check data quality metrics"""
    
    results = {
        "n_rows": len(df),
        "n_columns": len(df.columns),
        "issues": [],
        "column_quality": {},
        "overall_quality_score": 1.0
    }
    
    quality_scores = []
    
    for col in df.columns:
        col_info = {
            "dtype": str(df[col].dtype),
            "null_ratio": float(df[col].isnull().mean()),
            "unique_ratio": float(df[col].nunique() / len(df)) if len(df) > 0 else 0,
            "issues": []
        }
        
        # Score based on null ratio
        null_score = 1.0 - col_info["null_ratio"]
        
        # Check for all nulls
        if col_info["null_ratio"] == 1.0:
            col_info["issues"].append("all_null")
            results["issues"].append(f"Column {col} has all null values")
        elif col_info["null_ratio"] > 0.5:
            col_info["issues"].append("high_null_ratio")
            results["issues"].append(f"Column {col} has >50% null values")
        
        # Check for single value
        if df[col].nunique() == 1:
            col_info["issues"].append("single_value")
            results["issues"].append(f"Column {col} has only one unique value")
            null_score *= 0.5
        
        # Check for high cardinality
        if col_info["unique_ratio"] > 0.95 and len(df) > 100:
            col_info["issues"].append("high_cardinality")
            
        # Check for outliers (numeric columns)
        if pd.api.types.is_numeric_dtype(df[col]):
            q1 = df[col].quantile(0.25)
            q3 = df[col].quantile(0.75)
            iqr = q3 - q1
            
            if iqr > 0:
                lower_bound = q1 - 1.5 * iqr
                upper_bound = q3 + 1.5 * iqr
                outliers = ((df[col] < lower_bound) | (df[col] > upper_bound)).sum()
                outlier_ratio = outliers / len(df)
                
                col_info["outlier_ratio"] = float(outlier_ratio)
                
                if outlier_ratio > 0.1:
                    col_info["issues"].append("high_outliers")
                    results["issues"].append(f"Column {col} has >10% outliers")
                    null_score *= 0.9
        
        # Check data type consistency with reference
        if reference_df is not None and col in reference_df.columns:
            if df[col].dtype != reference_df[col].dtype:
                col_info["issues"].append("dtype_mismatch")
                results["issues"].append(f"Column {col} dtype mismatch with reference")
                null_score *= 0.8
        
        col_info["quality_score"] = null_score
        quality_scores.append(null_score)
        results["column_quality"][col] = col_info
    
    # Check for duplicates
    n_duplicates = df.duplicated().sum()
    if n_duplicates > 0:
        results["n_duplicates"] = int(n_duplicates)
        results["duplicate_ratio"] = float(n_duplicates / len(df))
        results["issues"].append(f"Found {n_duplicates} duplicate rows")
        quality_scores.append(1.0 - results["duplicate_ratio"])
    
    # Overall quality score
    if quality_scores:
        results["overall_quality_score"] = float(np.mean(quality_scores))
    
    # Add summary
    results["summary"] = {
        "n_issues": len(results["issues"]),
        "status": "good" if results["overall_quality_score"] > 0.8 else "needs_attention"
    }
    
    return results
