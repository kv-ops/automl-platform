"""AutoML Platform - Complete ML automation framework"""

__version__ = "2.0.0"

from .config.settings import EnhancedPlatformConfig, get_config, set_config
from .modeling.utils import load_model, save_model, predict, predict_proba
from .data.io import load_data, save_data, validate_dataframe, split_features_target
from .features.engineering import FeatureEngineer
from .features.selection import FeatureSelector
from .modeling.trainer import train_cv
from .explain.shap_lime import explain_global, explain_local
from .fairness.metrics import fairness_report, demographic_parity, equal_opportunity
from .monitoring.drift import check_drift
from .monitoring.quality import check_data_quality

__all__ = [
    "__version__",
    "EnhancedPlatformConfig", "get_config", "set_config",
    "load_model", "save_model", "predict", "predict_proba",
    "load_data", "save_data", "validate_dataframe", "split_features_target",
    "FeatureEngineer", "FeatureSelector",
    "train_cv",
    "explain_global", "explain_local",
    "fairness_report", "demographic_parity", "equal_opportunity",
    "check_drift", "check_data_quality"
]
